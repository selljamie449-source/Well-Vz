# Well-Viz Desktop — Code Guide

A code-level walkthrough of `well_viz.py`. The application is a single
~720-line Python file organised into four clearly-delimited sections; this
document explains the responsibility of each section, the public functions
inside it, and the extension points you can hook into when reusing the code
elsewhere.

For the mathematical background and references see
[`TECHNICAL_PAPER.md`](TECHNICAL_PAPER.md). For embedding patterns and
porting hints see [`INTEGRATION.md`](INTEGRATION.md).

---

## Project layout

```
well-viz-desktop/
├─ well_viz.py              ← the entire application
├─ requirements.txt         ← numpy, matplotlib
├─ README.md                ← user-facing quick-start
├─ docs/
│  ├─ TECHNICAL_PAPER.md    ← math + references
│  ├─ CODE_GUIDE.md         ← this file
│  └─ INTEGRATION.md        ← reuse & porting
├─ data/                    ← bundled example surveys
│  ├─ vertical.csv          ← straight hole, MD ≈ TVD
│  ├─ deviated.csv          ← classic J-shape build-and-hold
│  ├─ horizontal.csv        ← vertical → 90° build → 3500 ft lateral
│  ├─ extended-reach.csv    ← 22,000 ft MD with ~12,000 ft of lateral
│  ├─ multilateral.json     ← one JSON with 3 bores (main + 2 laterals)
│  ├─ sagd-pair.json        ← injector + producer, 16 ft vertical spacing
│  ├─ leg-main.csv          ← same multilateral, split per-leg (3 CSVs)
│  ├─ leg-north.csv
│  └─ leg-south.csv
└─ tests/
   └─ test_wellbore.py      ← closed-form regression tests
```

---

## The five sections of `well_viz.py`

```
┌────────────────────────────────────────────────────────────────────┐
│ 1. Minimum-curvature trajectory math                               │
│       _dogleg_rad / _ratio_factor (private helpers)                │
│       minimum_curvature()  ← public  (honours file values)         │
│       densify() / _interp_azi (visual smoothing)                   │
│       compute_summary()    ← public                                │
├────────────────────────────────────────────────────────────────────┤
│ 2. CSV + JSON input parsing                                        │
│       parse_csv()          ← public  (req. + optional cols)        │
│       parse_json()         ← public                                │
│       load_survey()        ← public  (file → bores)                │
│       load_from_text()     ← public  (stdin / pasted text)         │
│       load_legs()          ← public  (multi-file → bores)          │
│       load_plan_vs_actual()← public  (plan vs actual pairs)        │
├────────────────────────────────────────────────────────────────────┤
│ 3. Matplotlib rendering (multi-panel)                              │
│       DEFAULT_COLORS  +  _BG / _PANE / _GRID / _FG / ...           │
│       plot_wells()         ← public                                │
│       _prepare_bores       (compute trajectory + densify per bore) │
│       _find_plan_actual_pairs (match planned/actual by name)       │
│       _compute_deviation   (per-station actual-vs-plan offsets)    │
│       _build_layout        (gridspec dispatcher)                   │
│       _draw_3d / _draw_dls_colored_line                            │
│       _draw_plan_view / _draw_section_view                         │
│       _draw_deviation_panel                                        │
│       _draw_md_markers / _densify_raw / _equal_3d_box              │
├────────────────────────────────────────────────────────────────────┤
│ 4. Upload GUI (tkinter)                                            │
│       launch_gui()             ← public  (--gui entry point)       │
│       _build_bores_for_gui     (helper)                            │
│       _guess_role_from_filename (auto-pair heuristic)              │
│       _quick_metadata           (per-file preview for table row)   │
├────────────────────────────────────────────────────────────────────┤
│ 5. CLI                                                              │
│       list_examples / find_example                                 │
│       main()               ← entry point                           │
└────────────────────────────────────────────────────────────────────┘
```

The dividing comments in the source are deliberate — each section's
functions only depend on earlier sections, so you can take the math
(section 1) in isolation, ignore the plotting and CLI, and use it as a
library.

---

## Section 1 — Trajectory math

### `minimum_curvature(stations, surface_x=0, surface_y=0, surface_z=0)`

The core function. Takes a list of station dicts of shape
`{"md": float, "inc": float, "azi": float}` (with optional `tvd`, `north`,
`east`, `dls` if the file supplied them) and returns a list of the same
length with the following fields populated on every station:

| Field                    | Meaning                                                |
|--------------------------|--------------------------------------------------------|
| `north`, `east`, `tvd`   | 3-D position in the same units as MD                    |
| `dls`                    | Dogleg severity                                         |
| `horizontalDisplacement` | $\sqrt{N^2 + E^2}$ — used by classification              |
| `_source`                | `{"tvd","north","east","dls": "file"|"computed"}` provenance |
| `_calc_*`                | Internal running accumulators (computed values) for chaining segments |

**File values are honoured.** If a station already carries `tvd`,
`north`, `east`, or `dls`, those values are preserved verbatim in the
output instead of being overwritten. The computed position is still
tracked internally (`_calc_*`) so subsequent segments remain consistent
with the previous *computed* point — overrides only affect the *reported*
values for the station that supplied them, never the math for the next
segment.

This matters because TVD/DLS reported by the user's planning software
(Compass, WellPlan, Petrel, etc.) may be the engineering team's source of
truth — silently recomputing them would create discrepancies with
downstream workflows.

`compute_summary` and `plot_wells` use the reported (file-or-computed)
values; `_aggregate_sources` and the text summary printout surface which
fields came from where.

The `surface_x/y/z` arguments shift the starting point of the trajectory.
This is what enables pad-scale multi-well layouts.

**Complexity:** O(n) in number of stations. Computation cost is one `acos`,
one `tan`, and a handful of trig evaluations per pair — negligible even
for 100,000-station surveys.

**Errors:**
- `ValueError` if MD is not monotonically non-decreasing.

### `densify(stations, step_md=50.0)` / `_densify_raw(...)`

Visual-only helper. Returns a new station list with linearly-interpolated
intermediate stations inserted every `step_md` along MD. The interpolation
respects compass wraparound for azimuth (see §7.4 of the technical paper).
After densification the same `minimum_curvature` math is applied to the
sub-sampled stations — the original surveyed stations' positions are
preserved exactly; only the visual line between them is refined.

Pass `step_md=0` to disable densification (`plot_wells(..., densify_step=0)`).

### `compute_summary(stations)`

Aggregates a finished trajectory into a single dict:

```python
{
  "stationCount":      int,
  "totalMd":           float,
  "totalTvd":          float,
  "horizontalReach":   float,
  "maxInclination":    float,
  "maxDls":            float,
  "classification":    "vertical" | "deviated" | "horizontal" | "high-angle"
}
```

Classification rules:

```
max_inc < 30                                   →  vertical
30  ≤ max_inc < 80                             →  deviated
max_inc ≥ 80  and  reach > final TVD            →  horizontal
max_inc ≥ 80  and  reach ≤ final TVD            →  high-angle
```

---

## Section 2 — Input parsing

### `parse_csv(text) -> List[dict]`

Parses a CSV string into station dicts.

- Header row required.
- Required columns: `md`, `inc`, `azi` (case-insensitive). Aliases like
  `MeasuredDepth`, `Inclination`, `Azimuth`, `MD`, `INC`, `AZI` are accepted.
  Header normalization strips spaces, hyphens, and underscores before
  matching.
- Lines beginning with `#` are treated as comments.
- Other columns are silently ignored, so industry survey exports with
  extra fields (DLS, course length, comments, etc.) load without surgery.

### `parse_json(text)`

Returns `{"bores": [bore_dict, ...], "meta": {...}}`.

Two input shapes are accepted:

1. **Array of station dicts** — treated as a single bore named "Wellbore".

   ```json
   [{"md": 0, "inc": 0, "azi": 0}, ...]
   ```

2. **Multi-bore envelope** — used for multilaterals, SAGD pairs,
   pad-scale layouts.

   ```json
   {
     "meta":  {...optional metadata...},
     "bores": [
       {
         "name":     "Main",
         "color":    "#0284c7",
         "surfaceX": 0,
         "surfaceY": 0,
         "surfaceZ": 0,
         "stations": [ {"md": 0, "inc": 0, "azi": 0}, ... ]
       }
     ]
   }
   ```

### `load_survey(path) -> List[bore_dict]`

Reads a file from disk and returns a list of bores. CSV files return a
one-element list. JSON files may return one or many bores depending on
their shape.

### `load_from_text(text, format="csv")`

The stdin equivalent. Auto-detects JSON if the first non-whitespace
character is `{` or `[`.

### `load_legs(paths, names=None, colors=None) -> List[bore_dict]`

Loads multiple files as separate legs of a single multilateral well. Each
file is expected to contain a complete survey from surface to that leg's
toe — the format directional surveyors typically deliver one file per
lateral. The shared upper section naturally overlaps in 3-D space because
every leg starts at MD = 0.

If `names` is provided, it overrides leg labels positionally. Likewise for
`colors` (any matplotlib-accepted colour spec). If `names` is omitted, the
filename stem (title-cased) is used as the legend label.

### `load_plan_vs_actual(planned_paths, actual_paths, names=None, colors=None)`

Loads two parallel sequences of files for side-by-side plan-vs-actual
comparison. Each `planned_paths[i]` is paired positionally with
`actual_paths[i]`; the pair shares one colour and one display name. Each
returned bore has a `role` field set to either `"planned"` or `"actual"`,
which `plot_wells` interprets to apply the dashed-translucent styling.

The two lists may be different lengths — an in-progress multilateral
where only some legs have been drilled will produce orphan planned bores
with no actual companion (rendered alone, full-coloured but still dashed
because their `role` is `"planned"`).

### The `role` field

Any bore dict may carry an optional `role`:

```python
{"name": "Main", "role": "planned", "stations": [...]}   # dashed, alpha 0.45
{"name": "Main", "role": "actual",  "stations": [...]}   # solid, alpha 1.0
{"name": "Main",                    "stations": [...]}   # treated as "actual"
```

`plot_wells` is the only consumer; all other functions ignore it. The
field round-trips through JSON envelopes (`parse_json` preserves it) so
multi-bore plan/actual sets can also be packaged as a single JSON file.

---

## Section 3 — Rendering

### `plot_wells(bores, *, densify_step=50.0, show_md_markers=True, title=None, save_path=None, color_by_dls=False, show_plan_view=True, show_section_view=True, show_deviation_panel=True)`

Builds and shows the matplotlib figure as a multi-panel dashboard. If
`save_path` is provided, the figure is rendered headlessly and written as
a PNG instead of opened in a window.

**Panels:**

| Panel               | Shown when                                  |
|--------------------|----------------------------------------------|
| 3D view            | Always                                       |
| Plan view (top-down) | `show_plan_view=True`                      |
| Section view       | `show_section_view=True`                     |
| Deviation panel    | Plan + actual pair found and `show_deviation_panel=True` |
| DLS colour bar     | `color_by_dls=True`                          |

Layout is selected by `_build_layout` via `matplotlib.gridspec`. The 3-D
view always takes the largest area; insets stack on the right; the
deviation panel spans the bottom row.

**Pipeline per bore:**

```
raw stations
    │
    ├─→ minimum_curvature()          # honours file TVD/N/E/DLS values
    │       └─→ coarse trajectory + summary
    │
    ├─→ keep_file_fields + densify   # extra MD-spaced stations for smooth line
    │       └─→ fine trajectory       # → np arrays of e/n/t/md/dls
    │
    └─→ stored in `prepared` dict for later panel drawers
```

### Plan-vs-actual deviation

`_find_plan_actual_pairs(prepared)` matches bores by display name (one
with `role="planned"`, one with `role="actual"`). For each pair,
`_compute_deviation(plan, actual)` linearly interpolates the planned
trajectory at every actual-station MD and computes:

- `d_north`, `d_east`, `d_tvd` — signed deltas (actual − plan)
- `d_horizontal = √(d_north² + d_east²)`
- `d_total = √(d_horizontal² + d_tvd²)`
- Summary stats: `max_total` + the MD where it occurs, `rms_total`

The same numbers feed both the on-screen deviation panel and the text
summary printed to the console.

### DLS heatmap

When `color_by_dls=True`, `_draw_dls_colored_line` replaces the single
plotted line with a `Line3DCollection` whose segments are coloured by DLS.
The colour normalisation is capped at the 95th percentile so a single
high-DLS outlier doesn't wash out the rest. Planned/actual line styles
(dashed vs solid) are kept even when DLS coloured, so you can still
distinguish them.

For each bore:

1. Run `minimum_curvature` on the raw stations (with optional surface
   offset).
2. Run `_densify_raw` + `minimum_curvature` again for visual smoothing.
3. `ax.plot(...)` the 3-D polyline.
4. Drop a wellhead sphere (amber, MD = 0) and a toe triangle
   (bore-coloured, last station).
5. Optionally annotate MD ring markers along the path.
6. Add a legend entry with the bore's classification.

The function ends by:

- Inverting the Z axis so depth is positive-down on screen.
- Setting the 3-D box aspect ratio to the data range so the trajectory
  shape isn't distorted.
- Setting an oblique camera (`elev=20, azim=-60`).
- Printing a text summary table to stdout.

### Theme constants

The block of `_BG / _PANE / _GRID / _FG / _FG_DIM / _WELLHEAD / _MD_LABEL /
_MD_DOT / _LEGEND_BG / _LEGEND_EDGE` constants near the top of the section
controls the visual style. Override them in code to retheme the plot
without touching `plot_wells`.

`DEFAULT_COLORS` lists six high-contrast hex colours used round-robin
across bores. Override per-bore via the `color` field in JSON inputs or
the `--colors` CLI flag.

---

## Section 4 — CLI

### `main(argv=None) -> int`

argparse-based command-line dispatcher. Recognised flags:

| Flag              | Meaning                                                  |
|-------------------|----------------------------------------------------------|
| (positional)      | One or more CSV/JSON files; or `-` for stdin             |
| `--example NAME`  | Load a bundled example by stem name                      |
| `--list-examples` | Print the bundled examples and exit                      |
| `--names "A,B,C"` | Override per-leg labels positionally                     |
| `--colors "#a,#b"`| Override per-leg colours positionally                    |
| `--no-markers`    | Hide MD ring markers                                     |
| `--densify N`     | Visual smoothing step in MD units (default 50; 0 = off)  |
| `--save PATH`     | Render to PNG instead of opening a window                |
| `--stdin-format`  | Force `csv` or `json` interpretation of stdin            |

Routing logic:

```
len(source) == 0  → bundled "deviated" example (auto-shown on first run)
source == ["-"]   → read one survey from stdin
len(source) > 1   → multi-leg multilateral (call load_legs)
len(source) == 1  → single CSV or JSON file (call load_survey)
--example given   → take precedence over a missing source
```

---

## Data flow

```
                      ┌──────────────────┐
   CSV file ─────────►│ parse_csv        │─┐
   JSON file ────────►│ parse_json       │ │
   stdin    ─────────►│ load_from_text   │ │
   CLI argv ─────────►│ load_legs        │ │
                      └──────────────────┘ │
                                           ▼
                       List[{"name": str,
                             "stations": [{md, inc, azi}, ...],
                             "color"?, "surfaceX"?, ...}]
                                           │
                                           ▼
                                ┌───────────────────────┐
                                │ minimum_curvature     │
                                │   (per bore, twice:   │
                                │    coarse + densified)│
                                └───────────────────────┘
                                           │
                                           ▼
                                ┌───────────────────────┐
                                │ compute_summary       │
                                └───────────────────────┘
                                           │
                                           ▼
                                ┌───────────────────────┐
                                │ plot_wells            │
                                │   → matplotlib window │
                                │   → or save_path PNG  │
                                └───────────────────────┘
```

---

## Extension points

The code was deliberately kept loose so you can swap in alternative input
formats, calculation methods, or rendering backends without restructuring.

### Add a new input format (e.g. LAS, WITSML, Excel)

Write a `parse_yourformat(text) -> List[station_dict]` function and a
new `load_yourformat(path) -> List[bore_dict]` wrapper, then teach
`load_survey` (or `main`) to dispatch on the file extension.

The station dict shape (`{"md", "inc", "azi"}`) and the bore dict shape
(`{"name", "stations", "color"?, "surfaceX/Y/Z"?}`) are the only contracts
downstream code expects.

### Add another trajectory calculation method

`minimum_curvature` is one function with a clear input/output shape.
Implement `average_angle(stations, ...)` or `radius_of_curvature(...)`
with the same signature, then route `plot_wells` to whichever method
based on a new CLI flag. The summary, plotting, and CLI code are method-agnostic.

### Customise the visualization

Theme constants (`_BG`, `_FG`, etc.) are top-of-section globals — override
them before calling `plot_wells`. For deeper changes, the `ax` object
created inside `plot_wells` is a standard matplotlib 3-D axes — you can
overlay additional artists (geological layers, casing shoes, target
boxes) by extracting the axis-construction code into a helper that returns
`(fig, ax, summaries)` and calling it from your own code.

### Render headlessly in a server

`plot_wells(..., save_path="...")` is already headless-safe: it calls
`fig.savefig` and skips `plt.show`. For pure programmatic use:

```python
import matplotlib
matplotlib.use("Agg")  # headless backend, no GUI
from well_viz import load_survey, plot_wells
plot_wells(load_survey("survey.csv"), save_path="out.png")
```

Set the `Agg` backend before importing pyplot — `well_viz.py` imports
matplotlib at module load, so the backend choice has to come first.

### Add another well-type label

`compute_summary` is the one place where classification happens. Edit the
three-way conditional, no other code path depends on the exact label
strings.

---

## Testing

`tests/test_wellbore.py` uses only Python's standard `assert` plus a custom
`approx()` helper — no `pytest` required.

Run it directly:

```powershell
py tests/test_wellbore.py
```

Each test case is documented inline and corresponds to one of the four
closed-form scenarios described in §8 of `TECHNICAL_PAPER.md`. When you
extend the math (e.g. adding an alternative calculation method), add a new
closed-form test for the new code path; the existing pattern is easy to
copy.

---

## Performance notes

For a typical drilling-engineering workflow (≤ 500 stations per bore,
≤ 10 bores per plot) every part of the pipeline runs in well under 100 ms
on a modern laptop. The dominant cost is matplotlib's 3-D rendering, not
the trajectory math.

Heavier loads (10,000+ stations) are still fine on the math side but may
warrant disabling visual densification (`--densify 0`) and MD markers
(`--no-markers`) to keep matplotlib happy.

If you need to render dozens of bores or tens of thousands of stations
interactively, consider porting the plotter to **PyVista** (VTK under the
hood, GPU-accelerated) — see `INTEGRATION.md` for a sketch.
