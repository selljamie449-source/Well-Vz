# Well-Viz Desktop — Technical White Paper

**Subject:** Conversion of directional drilling survey data (MD / Inclination /
Azimuth) into 3D Cartesian wellbore trajectories using the minimum-curvature
method, with interactive visualization in Python.

**Version:** 1.0
**Document type:** Technical reference

---

## 1. Abstract

Directional and horizontal wells are recorded as discrete survey stations
along the borehole, each reporting measured depth (MD), inclination from
vertical (I), and azimuth from grid north (A). Converting that 1-D record
into a usable 3-D trajectory is the foundation of every well-planning,
anti-collision, geosteering, and reservoir-engineering workflow in the
upstream oil-and-gas industry.

This paper documents the mathematical model, coordinate conventions,
numerical safeguards, and visualization strategy used by **Well-Viz Desktop**,
a single-file Python application that ingests CSV/JSON surveys and renders
the resulting wellbore in an interactive 3-D matplotlib window. The math
implementation is the industry-standard **minimum-curvature method (MCM)**
described in API RP 78 and Bourgoyne et al.'s *Applied Drilling Engineering*,
and the implementation has been verified against four closed-form test cases.

The same engine handles every well geometry encountered in practice —
vertical, deviated (J-shape), extended-reach, horizontal, multilateral, and
SAGD well pairs — without code-path branching: every trajectory is treated
as a sequence of arc segments between survey stations.

---

## 2. Problem statement

A directional survey is a sequence of stations
$\{(\text{MD}_i, I_i, A_i)\}_{i=1\dots n}$, with:

- $\text{MD}_i$ — measured depth along the borehole (feet or metres).
- $I_i \in [0°, 180°]$ — inclination from vertical. $I = 0°$ is straight
  down; $I = 90°$ is horizontal; $I > 90°$ is "uphill" (rare; occurs in
  S-shaped wells and some sidetracks).
- $A_i \in [0°, 360°)$ — azimuth, measured clockwise from grid north when
  viewed from above.

The objective is to produce a 3-D path in Cartesian space — usually labelled
*(North, East, TVD)* where TVD is true vertical depth (positive downward) —
such that the path passes through every survey station with a geometry that
is consistent with the drilling assembly's curvature constraints.

Several methods exist for this conversion. They differ in how the borehole
geometry is assumed to behave **between** survey stations:

| Method                     | Assumption between stations | Industry adoption |
|---------------------------|-----------------------------|-------------------|
| Tangential                | Constant direction = upper station | Obsolete (high error on doglegs) |
| Balanced tangential       | Half each station's direction       | Limited |
| Average angle             | Mean of two stations' direction     | Educational |
| Radius-of-curvature       | Circular arc in horizontal & vertical planes separately | Niche |
| **Minimum curvature (MCM)** | Single circular arc on the unit sphere | **Industry standard** |

The minimum-curvature method is the universal choice today: it is the most
geometrically accurate of the closed-form methods, is mathematically smooth
(its position is C¹-continuous across stations), and has been adopted by
every major commercial wellbore-engineering package — Landmark COMPASS,
Halliburton WELLPLAN, Schlumberger Petrel, Peloton WellView, EDM, Drillscan,
and others.

---

## 3. The minimum-curvature method

### 3.1 Geometric premise

Between two consecutive stations, the wellbore is modelled as the shortest
circular arc on the unit sphere that connects the two tangent directions and
spans the recorded MD increment. The arc lies in the plane defined by the
two tangent vectors, and its curvature is constant along the segment.

This single assumption produces a unique, deterministic 3-D path for any
sequence of MD/I/A stations.

### 3.2 Tangent vectors

Define the unit tangent vector at station $i$ in the *(North, East, TVD)*
frame:

$$
\mathbf{T}_i \;=\;
\bigl(\; \sin I_i \cos A_i,\;
        \sin I_i \sin A_i,\;
        \cos I_i \;\bigr)
$$

A vertical well has $\mathbf{T} = (0, 0, 1)$ (pointing straight down). A
horizontal well headed due east has $\mathbf{T} = (0, 1, 0)$.

### 3.3 The dogleg angle

The dogleg angle $\beta$ between two adjacent tangents is the angular
distance between them, satisfying $\cos\beta = \mathbf{T}_1 \cdot \mathbf{T}_2$.
Expanding the dot product:

$$
\cos\beta
\;=\; \sin I_1 \sin I_2 \cos(A_2 - A_1)
   \;+\; \cos I_1 \cos I_2
$$

Using the identity
$\cos(I_2 - I_1) = \cos I_1 \cos I_2 + \sin I_1 \sin I_2$,
this simplifies algebraically to the canonical industry form:

$$
\boxed{\;
  \cos\beta \;=\; \cos(I_2 - I_1)
              \;-\; \sin I_1 \sin I_2 \bigl[1 - \cos(A_2 - A_1)\bigr]
\;}
$$

In code (`well_viz.py:_dogleg_rad`):

```python
cos_dl = math.cos(i2 - i1) - math.sin(i1) * math.sin(i2) * (1 - math.cos(a2 - a1))
return math.acos(max(-1.0, min(1.0, cos_dl)))
```

The clamp to $[-1, 1]$ protects against floating-point drift when the two
tangents are nearly parallel ($\cos\beta$ can otherwise evaluate to e.g.
$1.0000000004$, which breaks `acos`).

### 3.4 The ratio factor

The position increment along a circular arc of dogleg $\beta$ is not the
straight chord between $\mathbf{T}_1$ and $\mathbf{T}_2$; it is slightly
longer because the path follows the arc. The minimum-curvature method
applies a dimensionless **ratio factor** $\text{RF}(\beta)$ to convert
chord into arc:

$$
\boxed{\;
\text{RF}(\beta) \;=\; \frac{2}{\beta} \tan\!\left(\frac{\beta}{2}\right)
\;}
$$

Limit behaviour:

- As $\beta \to 0$, $\tan(\beta/2) \approx \beta/2$ so $\text{RF} \to 1$.
  This recovers the **balanced tangential** result (correct for straight
  segments).
- For $\beta = \pi/2$ (a 90° turn), $\text{RF} = (4/\pi)\tan(\pi/4)
  = 4/\pi \approx 1.2732$.

The code (`well_viz.py:_ratio_factor`) short-circuits the formula for
near-zero doglegs:

```python
if dl < 1e-9:
    return 1.0
return (2.0 / dl) * math.tan(dl / 2.0)
```

### 3.5 Position deltas

For each pair of consecutive stations:

$$
\begin{aligned}
\Delta\text{MD}\;   &=\; \text{MD}_2 - \text{MD}_1 \\[2pt]
\Delta N \;          &=\; \tfrac{\Delta\text{MD}}{2}
                          \bigl(\sin I_1 \cos A_1 + \sin I_2 \cos A_2\bigr)
                          \cdot \text{RF}(\beta) \\
\Delta E \;          &=\; \tfrac{\Delta\text{MD}}{2}
                          \bigl(\sin I_1 \sin A_1 + \sin I_2 \sin A_2\bigr)
                          \cdot \text{RF}(\beta) \\
\Delta\text{TVD}\;   &=\; \tfrac{\Delta\text{MD}}{2}
                          \bigl(\cos I_1 + \cos I_2\bigr)
                          \cdot \text{RF}(\beta)
\end{aligned}
$$

These can be derived directly from the vector form
$\Delta\mathbf{P} \;=\; \tfrac{\Delta\text{MD}}{2}\,(\mathbf{T}_1 + \mathbf{T}_2)
\cdot \text{RF}(\beta)$
by substituting the component definitions of $\mathbf{T}_i$.

Cumulative position is obtained by summing the deltas from the wellhead:

$$
(N_n,\, E_n,\, \text{TVD}_n)
\;=\; (N_0, E_0, \text{TVD}_0) + \sum_{i=1}^{n-1} (\Delta N_i, \Delta E_i, \Delta\text{TVD}_i)
$$

The wellhead $(N_0, E_0, \text{TVD}_0)$ defaults to the origin but can be
shifted per-bore via the `surfaceX`, `surfaceY`, `surfaceZ` fields in
multi-bore JSON inputs — used to anchor wells of a SAGD pair or pad-scale
multi-well visualisation in a shared coordinate frame.

### 3.6 Dogleg severity

**Dogleg severity (DLS)** is the rate of change of borehole direction,
normalized to a standardised MD interval. It is the principal metric for
assessing well-trajectory complexity, casing-running risk, and
torque-and-drag concerns:

$$
\text{DLS}_{i,i+1} \;=\;
   \frac{\beta_{i,i+1} \;[\text{deg}]}{\Delta\text{MD}_{i,i+1}}
   \times 100
   \quad
   \bigl[\,°/100\text{ ft or }°/100\text{ m}\,\bigr]
$$

The unit (ft vs m) is inherited from the survey MD's unit. Field practice in
North America standardises on °/100 ft; metric jurisdictions use °/30 m
(numerically identical when MD is in metres and the same factor of 100 is
applied — 100 m ≈ 30 m × 3.33 — but the convention in this codebase is to
report deg-per-100-units regardless of unit).

---

## 4. Coordinate systems

Two distinct coordinate frames are used:

### 4.1 Survey / engineering frame

| Axis | Direction              | Sign convention      |
|------|------------------------|----------------------|
| $N$  | Grid North             | Positive = north     |
| $E$  | Grid East              | Positive = east      |
| TVD  | True Vertical Depth    | **Positive = down**  |

This is the frame in which trajectory math is performed and in which
positions are reported to the user.

### 4.2 Visualization frame

matplotlib's 3-D axes use a right-handed Cartesian frame with $Z$ pointing
"up" on screen. To present TVD correctly (deeper = lower on screen) while
keeping tick labels positive, the engineering frame is mapped to the plot
frame and the Z axis is then inverted:

| Engineering | Plot axis        | Notes                                  |
|-------------|------------------|----------------------------------------|
| East        | $X$              | Direct mapping                         |
| North       | $Y$              | Direct mapping                         |
| TVD         | $Z$ (inverted)   | `ax.invert_zaxis()` flips display      |

The plot's bounding-box aspect ratio is forced to match the data range
(`ax.set_box_aspect`) so trajectory shape is not distorted. For
extended-reach wells with very large reach/TVD ratios the resulting figure
is correspondingly wide; this is the geometrically correct rendering.

---

## 5. Handling multi-bore geometries

The math engine is single-bore; multi-bore wells are computed as independent
trajectories sharing a coordinate frame.

### 5.1 Multilaterals

A multilateral well has a parent (or "main") bore and one or more lateral
re-entries that branch from the parent at a junction MD. In field practice,
each leg is delivered as a separate survey file containing a **complete**
record from surface to the toe of that leg — the parent bore's survey is
repeated in every lateral file above the kickoff.

Well-Viz treats every leg as an independent bore beginning at the surface.
Because the laterals' MD/Inc/Azi stations are identical above the junction,
their computed 3-D positions overlap exactly in the shared section and only
diverge from the kickoff onward. This produces a geometrically correct
multilateral rendering with no special-case logic.

```
        Surface (MD = 0)
           │
           │   <-- shared trajectory (all legs identical here)
           │
           ▼
    Kickoff (MD ≈ 4000 ft)
       │   ╲
       │    ╲
       ▼     ▼
    Main   Lateral 1 ...
```

### 5.2 SAGD (Steam-Assisted Gravity Drainage) well pairs

SAGD wells are drilled in pairs: a steam injector above and a bitumen
producer typically 5 m (16 ft) below it. Both wells run as long parallel
horizontals through an oil-sands reservoir.

In Well-Viz, each well of the pair is a separate bore. The vertical spacing
is achieved by adding 16 ft of extra MD to the producer's vertical section
before its kickoff, so that — after applying minimum curvature to both — the
toes settle exactly 16 ft apart in TVD while the horizontal sections remain
parallel. The bundled `data/sagd-pair.json` demonstrates this.

### 5.3 Plan vs actual (as-drilled) comparison

A standard operational check during drilling is to overlay the **planned**
trajectory (the engineering design the well was approved against) with the
**actual** trajectory (the as-drilled survey reported from MWD tools at the
current bit depth). Deviation between the two indicates drilling drift
caused by formation tendency, BHA imbalance, or sliding-vs-rotating
choices made on the rig floor.

The math engine treats planned and actual surveys identically — both are
just sequences of MD/Inc/Azi stations passed through minimum curvature.
The distinction is purely visual: planned trajectories are rendered as
dashed translucent lines with hollow toe markers (the *target* location),
and actual trajectories are rendered solid with filled toe markers (the
*current bit* location). Matching pairs share a colour so the visual
divergence between plan and actual reads at a glance.

Typical interpretations:

| Observation                                       | Likely cause                                  |
|---------------------------------------------------|-----------------------------------------------|
| Actual lags behind plan in the build curve        | Tool tendency to under-build; slow ROP        |
| Actual ahead of plan in the build curve           | Bent-housing motor over-building              |
| Azimuth walks consistently one direction          | Formation dip; bit walk; magnetic interference|
| Actual TVD shallower than plan at same MD         | Under-build of inclination                    |
| Actual TVD deeper than plan at same MD            | Over-build of inclination                     |

The Well-Viz implementation supports this workflow via the `role` field
on each bore (`"planned"` or `"actual"`); see `INTEGRATION.md` §1 and the
CLI `--planned` / `--actual` flags documented in `README.md`.

### 5.4 Pad-scale offsets

For multi-well pads where each wellhead sits at a different surface
location, the JSON envelope accepts per-bore `surfaceX`, `surfaceY`,
`surfaceZ` fields. These are passed straight through to the trajectory
calculation as the initial $(E_0, N_0, \text{TVD}_0)$ for that bore.

---

## 6. Well-type classification

A simple heuristic tags each computed trajectory with one of four labels
based on terminal inclination and horizontal-reach-to-TVD ratio:

| Class       | Condition                                          |
|-------------|----------------------------------------------------|
| `vertical`  | max inclination $< 30°$                            |
| `deviated`  | max inclination in $[30°, 80°)$                    |
| `horizontal`| max inclination $\geq 80°$ **and** reach > final TVD |
| `high-angle`| max inclination $\geq 80°$ but reach ≤ final TVD   |

The classification is informational only — the visualization is identical
regardless of label. The label is shown in the legend, the title summary,
and the text summary printed to the terminal.

---

## 7. Numerical considerations

### 7.1 Floating-point clamping

`acos` is undefined outside $[-1, 1]$. Floating-point arithmetic on
near-parallel tangent vectors can produce values like $1 + 4\times10^{-10}$,
which `math.acos` rejects. The implementation clamps the cosine to $[-1, 1]$
before passing to `acos`:

```python
return math.acos(max(-1.0, min(1.0, cos_dl)))
```

### 7.2 Ratio factor near zero

$\text{RF}(\beta)$ has the indeterminate form $0/0$ at $\beta = 0$. The
limit is exactly 1, recoverable by L'Hôpital. The code substitutes the
limit when $\beta < 10^{-9}$ rad to avoid division by a near-zero quantity.

### 7.3 Monotonic MD

Minimum curvature assumes MD is monotonically non-decreasing along the
survey. The code sorts by MD on entry and raises `ValueError` if any
station has MD less than its predecessor.

### 7.4 Azimuth wrap-around for visualization

When sub-sampling the survey for smoother rendering, interpolating azimuth
linearly fails for wraps across 360° / 0° (e.g. 350° → 10°). The helper
`_interp_azi` interpolates over the shorter arc on the compass:

```python
def _interp_azi(a, b, t):
    diff = ((b - a + 540.0) % 360.0) - 180.0
    return (a + diff * t) % 360.0
```

This affects the rendered polyline only; the math at the surveyed stations
remains exact.

### 7.5 Visual densification

Real-world surveys are often sparse (stations every 30 m / 100 ft is
typical) with denser sampling only across build curves and points of
interest. Plotting raw chord segments between sparse stations produces
visibly faceted curves. Well-Viz inserts evenly-spaced MD-interpolated
stations every 50 units between consecutive surveyed stations (using the
azimuth-aware interpolation above), then re-applies minimum curvature to
the densified sequence. The reported positions at original station MDs are
unchanged; only the line geometry between them is refined.

---

## 8. Verification

The `tests/test_wellbore.py` script validates the math against four
closed-form cases. Each is a result that can be derived analytically and
checked to machine precision.

### 8.1 Pure vertical well

For a survey with all stations at $I = 0$:

- $\sin I = 0 \Rightarrow \Delta N = \Delta E = 0$
- $\cos I = 1 \Rightarrow \Delta\text{TVD} = \Delta\text{MD}$

Expected: $N_i = E_i = 0$ and $\text{TVD}_i = \text{MD}_i$ for all $i$.

### 8.2 90° dogleg build curve

For a survey $(\text{MD}, I, A) = (0,\,0°,\,0°) \to (1000,\,90°,\,90°)$:

$$
\begin{aligned}
\beta &= 90° = \pi/2 \\
\text{RF} &= (2/(\pi/2))\tan(\pi/4) = 4/\pi \\
\Delta E &= 500 \cdot 1 \cdot 4/\pi = 2000/\pi \;\approx\; 636.62 \\
\Delta\text{TVD} &= 500 \cdot 1 \cdot 4/\pi = 2000/\pi \;\approx\; 636.62 \\
\Delta N &= 0 \\
\text{DLS} &= 90° \cdot 100 / 1000 = 9 \;°/100\text{ ft}
\end{aligned}
$$

### 8.3 Horizontal hold

For a survey $(0,\,90°,\,90°) \to (1000,\,90°,\,90°)$:

- $\beta = 0,\;\text{RF} = 1$
- $\Delta\text{TVD} = 0$
- $\Delta E = 1000,\;\Delta N = 0$

### 8.4 Classification

A vertical-then-horizontal well must classify as `horizontal` or
`high-angle`, never `vertical` or `deviated`. The classification heuristic
in §6 is exercised against a synthetic four-station survey.

All four tests pass to within machine epsilon on the bundled implementation;
see the `tests/` directory.

---

## 9. References

1. **API Recommended Practice 78** — *Wellbore Survey Accuracy*.
   American Petroleum Institute.
2. **Bourgoyne, A. T.; Millheim, K. K.; Chenevert, M. E.; Young, F. S.** —
   *Applied Drilling Engineering*. SPE Textbook Series, Vol. 2. Chapter 8
   covers directional surveying calculations.
3. **Sawaryn, S. J.; Thorogood, J. L.** — *A Compendium of Directional
   Calculations Based on the Minimum Curvature Method*.
   SPE 84246, 2005. The authoritative SPE paper on MCM.
4. **Wolff, C. J. M.; de Wardt, J. P.** — *Borehole Position Uncertainty —
   Analysis of Measuring Methods and Derivation of Systematic Error Model*.
   SPE 9223, 1981. Industry-defining paper on directional-survey error budgets.
5. **Industry Steering Committee on Wellbore Survey Accuracy (ISCWSA)** —
   the modern successor body that maintains error-model standards for
   commercial directional-survey software.

---

## 10. License & provenance

This implementation is original code written for the Well-Viz Desktop
reference application. The minimum-curvature method itself is in the public
domain (the underlying SPE/API publications are widely cited and the
algorithm is not patented). Adapt the code and this document freely; please
preserve the references in §9 in any derivative work.
