# Well-Viz Desktop

Pure-Python 3D directional-survey visualizer. Give it an MD/Inc/Azi survey
and it pops up a matplotlib 3D window you can rotate, zoom, and pan with the
mouse. No web server, no browser, no Node — just one script.

Supports every common well geometry:

| Well type                     | Sample file                |
|-------------------------------|----------------------------|
| Vertical                      | `data/vertical.csv`        |
| Deviated (J-shape)            | `data/deviated.csv`        |
| Horizontal                    | `data/horizontal.csv`      |
| Extended-reach (ERW)          | `data/extended-reach.csv`  |
| Multilateral (main + 2 legs)  | `data/multilateral.json`   |
| SAGD well pair                | `data/sagd-pair.json`      |

---

## Install

Requires **Python 3.10+**.

```powershell
py -m pip install -r requirements.txt
```

(That's just `numpy` and `matplotlib`.)

---

## Run

```powershell
# Open the upload window (file pickers + plot button) ←  EASIEST WAY
py well_viz.py --gui

# Auto-load the bundled "deviated" example
py well_viz.py

# Plot your own survey
py well_viz.py path\to\survey.csv
py well_viz.py path\to\multilateral.json

# Plot a bundled example by name
py well_viz.py --example horizontal
py well_viz.py --example sagd-pair
py well_viz.py --example multilateral

# List bundled examples
py well_viz.py --list-examples

# Read from stdin
type survey.csv | py well_viz.py -

# Save a PNG instead of opening a window
py well_viz.py --example horizontal --save horizontal.png

# Display options
py well_viz.py --no-markers              # hide MD ring labels
py well_viz.py --color-by-dls            # colour line by dogleg severity
py well_viz.py --no-plan-view            # hide top-down inset
py well_viz.py --no-section-view         # hide vertical-section inset
py well_viz.py --no-deviation-panel      # hide plan-vs-actual deviation panel
```

On macOS / Linux replace `py` with `python3`.

---

## What you see in the plot

The plot is laid out as a multi-panel dashboard. Panels appear/disappear
automatically based on what's in the data and which display options are on.

| Panel                  | Shown when…                         | What it shows                          |
|------------------------|-------------------------------------|----------------------------------------|
| **3D view**            | Always                              | Interactive 3-D wellbore trajectory    |
| **Plan view**          | `--no-plan-view` not set            | Top-down: East × North                 |
| **Section view**       | `--no-section-view` not set         | Vertical: Horizontal × TVD             |
| **Deviation panel**    | Plan + actual pair present          | Actual-vs-plan offset along MD         |
| **DLS colour bar**     | `--color-by-dls` set                | Trajectory coloured by dogleg severity |

Console output also includes a deviation summary table when planned/actual
pairs are present:

```
Plan-vs-Actual deviation (actual - plan)
----------------------------------------------------------------
Pair                       Max 3D        @MD        RMS  MeanHoriz
Deviated Well               582.0     6000.0     277.82      188.0
```

- **Max 3D** — largest Euclidean distance between actual and plan, with the MD where it occurs
- **RMS** — root-mean-square of the per-station 3-D offset
- **MeanHoriz** — mean horizontal departure of actual from plan

---

## Upload window (GUI)

Run `py well_viz.py --gui` and the upload window opens:

```
┌────────────────────────────────────────────────────────────────────┐
│ Well-Viz 3D                                                          │
│ Upload directional survey files, then click Plot. Files with         │
│ 'plan' or 'actual' in the filename are auto-tagged.                  │
│                                                                       │
│ [+ Add Survey File(s)…]  [+ Force Planned]  [+ Force Actual]  [+ Force Standalone]  │
│                                                                       │
│ Loaded surveys                                                        │
│ ┌─────────────────────────────────────────────────────────────────┐ │
│ │ Role        File / Name           Stns  MD range    Type        │ │
│ ├─────────────────────────────────────────────────────────────────┤ │
│ │ PLANNED     plan-deviated.csv     16    0–6000      deviated    │ │
│ │ ACTUAL      actual-deviated.csv   16    0–6000      deviated    │ │
│ │ STANDALONE  lateral-2.csv         11    0–6500      horizontal  │ │
│ └─────────────────────────────────────────────────────────────────┘ │
│ [Remove selected] [Rename selected] [Clear all]                       │
│   Right-click a row to change its role.                              │
│                                                                       │
│ Display options                                                       │
│ [×] MD markers   [×] Plan view  [×] Section view                     │
│ [×] Plan-vs-actual deviation panel   [ ] Colour trajectory by DLS    │
│                                                                       │
│                                              [Cancel] [Plot  ▶]      │
└────────────────────────────────────────────────────────────────────┘
```

**Key features:**

- **One "Add" button** that auto-tags by filename: anything containing
  `plan`, `planned`, `design`, `target` → **Planned**; anything containing
  `actual`, `as-drilled`, `survey` → **Actual**; everything else → **Standalone**.
  Override with the three "Force…" buttons if the heuristic gets it wrong.
- **Per-file metadata** appears the moment you add a file: station count,
  MD range, and classification (vertical / deviated / horizontal). If a
  file fails to parse, the row shows the error in red.
- **Right-click any row** to change its role, rename it, or remove it.
  Double-click to rename quickly. Delete key removes selection.
- **Multi-select supported** in the file picker (Ctrl/Shift) and the table.
- **Display option checkboxes** for MD markers, plan view, section view,
  deviation panel, and DLS heatmap — all configurable per-plot from the
  GUI.

After clicking **Plot ▶** the window closes and matplotlib opens.

No tkinter on your machine? On Debian/Ubuntu run
`sudo apt install python3-tk`. On Windows and macOS it ships with the
official Python installer.

---

## Multilateral wells — one file per leg

Directional surveys for multilateral wells are usually delivered as **one
file per leg**, where each file contains a complete survey from surface to
the toe of that lateral. Pass them all as positional arguments and each is
rendered as its own bore:

```powershell
# 3-leg multilateral, each leg is its own CSV
py well_viz.py data\leg-main.csv data\leg-north.csv data\leg-south.csv

# Override labels (positional, one per file)
py well_viz.py L1.csv L2.csv L3.csv ^
  --names "Main Bore,North Lateral,South Lateral"

# Override colours too
py well_viz.py L1.csv L2.csv L3.csv ^
  --colors "#38bdf8,#22c55e,#f97316"

# Mix CSV and JSON — works fine
py well_viz.py main.csv lat1.json lat2.csv

# Any number of legs is supported (2, 3, 4, ...)
py well_viz.py L1.csv L2.csv L3.csv L4.csv L5.csv
```

The shared upper section (surface down to the kickoff) is naturally drawn by
every leg — they overlap in 3D because their MD/Inc/Azi values are the same
above the junction. The legs only visually diverge from the kickoff onward.

Bundled example legs are in `data/leg-main.csv`, `data/leg-north.csv`, and
`data/leg-south.csv` — those three files together produce the same wellbore
as the single-file `data/multilateral.json`.

> **Tip — the legend label** is taken from the filename (so `leg-main.csv` →
> "Leg Main"). Use `--names` if you want something different, e.g.
> `--names "Pilot Hole,Re-entry 1,Re-entry 2"`.

---

## Planned vs actual — overlay comparison

A standard daily check during drilling: compare the **as-drilled** survey
against the **original well plan** to see where you're tracking the target
and where you've drifted. Pass the two surveys via `--planned` and
`--actual`. The plan renders **dashed + translucent**, the actual renders
solid + opaque, both share the same colour so the deviation pops:

```powershell
# Single well
py well_viz.py --planned plan.csv --actual actual.csv

# With a label
py well_viz.py --planned plan.csv --actual actual.csv --names "Lateral 1"

# Multi-leg: pair plans with actuals positionally (first plan ↔ first actual, etc.)
py well_viz.py ^
  --planned L1_plan.csv L2_plan.csv L3_plan.csv ^
  --actual  L1_act.csv  L2_act.csv  L3_act.csv ^
  --names "Main,North Lateral,South Lateral"

# In-progress drilling — more plans than actuals is fine
py well_viz.py --planned L1.csv L2.csv L3.csv --actual L1_act.csv L2_act.csv
# (L3 will render as plan only, no actual companion)
```

### What the comparison shows

| Element                | Plan                              | Actual                         |
|------------------------|-----------------------------------|--------------------------------|
| Line style             | Dashed, ~45 % opacity             | Solid, full opacity            |
| Color                  | Same as actual (paired)           | Same as plan (paired)          |
| Toe marker             | Hollow triangle = *target*        | Filled triangle = *bit position* |
| Wellhead               | Suppressed (shared with actual)   | Amber sphere                   |
| MD ring markers        | Hidden (avoids clutter)           | Shown along the path           |
| Legend tag             | "(planned)"                       | "(actual)"                     |

### Sample plan-vs-actual dataset

Bundled in `data/`:
- `plan-deviated.csv` — designed J-shape: kickoff at 1700 ft, build to 45°
  by 2500 ft on azimuth 090°, hold east to TD.
- `actual-deviated.csv` — same well as-drilled with realistic drift: delayed
  kickoff, ~10 % under-build, ~12° azimuth walk south of plan.

```powershell
py well_viz.py --planned data\plan-deviated.csv --actual data\actual-deviated.csv
```

You'll see the planned line track straight east and the actual line lag
slightly behind, ending shallower TVD and visibly south of plan.

### JSON envelope alternative

Inside a `bores` JSON file you can also tag each bore with `"role"`:

```json
{
  "bores": [
    {
      "name": "Main",
      "role": "planned",
      "color": "#0284c7",
      "stations": [ {"md": 0, "inc": 0, "azi": 0} ]
    },
    {
      "name": "Main",
      "role": "actual",
      "color": "#0284c7",
      "stations": [ {"md": 0, "inc": 0, "azi": 0} ]
    }
  ]
}
```

Renders identically to the `--planned/--actual` CLI form.

---

## Mouse controls

| Action | Mouse |
|---|---|
| Rotate the camera | **Left-drag** |
| Zoom              | **Right-drag** or scroll wheel |
| Pan               | **Middle-drag** |
| Reset view        | Toolbar home button (or close & re-run) |

The toolbar at the bottom of the matplotlib window also has save, pan,
and zoom-to-rectangle buttons.

---

## Input formats

### CSV — single bore

Header row required. Required columns: `md`, `inc`, `azi` (case-insensitive,
with aliases like `MeasuredDepth`, `Inclination`, `Azimuth`). Lines starting
with `#` are treated as comments.

```csv
md,inc,azi
0,0,0
1500,0,0
2500,45,90
6000,45,90
```

#### Industry-export format (with units in headers)

Most planning software (Compass, WellPlan, Petrel, etc.) exports surveys
with extra columns and units written into the header — for example:

```
MD (m), Inc (degrees), Azimuth ( degree), TVD (m), SS elevation (m),
N.offset (m), E.offset (m), Northing (m), Easting (m), Vs (m),
DLS (degree/30m), T.face (degree), B.rate (degree/30m),
Dist to plan (m), High to plan (m), Role to plan (m)
```

This format loads as-is. The header parser strips parenthesized unit
annotations (`MD (m)` → `md`, `Azimuth ( degree)` → `azimuth`) and
recognises common industry aliases (`N.offset`, `E.offset`, `DLS`, `TVD`,
`Measured Depth`, `Inclination`, etc).

**Important — file-supplied values are honoured.** When the file contains
**TVD**, **N.offset**, **E.offset**, or **DLS** columns, those values are
preserved verbatim instead of being recomputed via minimum curvature. Your
planning-software's calculations (potentially with manual corrections) are
the engineering source of truth — Well-Viz doesn't silently overwrite them.

Fields that are missing from the file are filled by minimum curvature so
minimal CSVs (md/inc/azi only) still work. Each plot prints a summary
showing exactly which fields came from the file:

```
Position fields honoured from file (rather than recomputed):
  Industry Format: dls, east, north, tvd
```

Columns the parser doesn't recognise (SS elevation, Northing/Easting in
absolute grid coordinates, Vs, T.face, B.rate, Dist to plan, etc.) are
silently ignored — they don't affect the trajectory.

A sample file in this exact format is bundled:

```powershell
py well_viz.py data\industry-format.csv
```

### JSON — single bore

```json
[
  { "md": 0,    "inc": 0,  "azi": 0   },
  { "md": 1500, "inc": 0,  "azi": 0   },
  { "md": 2500, "inc": 45, "azi": 90  }
]
```

### JSON — multi-bore (multilateral, SAGD pair)

```json
{
  "meta": { "well": "ML-01" },
  "bores": [
    {
      "name": "Main Bore",
      "color": "#38bdf8",
      "stations": [ { "md": 0, "inc": 0, "azi": 0 } ]
    },
    {
      "name": "Lateral 1",
      "color": "#22c55e",
      "stations": [ { "md": 0, "inc": 0, "azi": 0 } ]
    }
  ]
}
```

Optional per-bore fields `surfaceX`, `surfaceY`, `surfaceZ` anchor a bore's
wellhead at an offset from origin — useful when multiple wells share a pad
but have distinct surface locations.

### Two ways to represent a multilateral

You can pick whichever matches how your surveys arrive:

| Representation                                           | How to load it                                   |
|----------------------------------------------------------|--------------------------------------------------|
| **One file per leg** (most common in field data)         | `py well_viz.py L1.csv L2.csv L3.csv`            |
| **One JSON file containing all bores under `"bores"`**   | `py well_viz.py multilateral.json`               |

Both produce identical 3D output. The per-file approach is closer to the
raw data drillers receive; the single-JSON approach is handier when you want
to ship one self-contained well plan.

---

## What the plot shows

- **Coloured tube** — the 3D wellbore trajectory, smoothed by inserting
  interpolated MD steps between surveyed stations.
- **Yellow sphere** — wellhead (MD = 0).
- **Coloured triangle** — bit / toe (last station).
- **Grey dots + labels** — MD markers along the wellpath every ~500 ft.
- **Axes** — East / North on the floor, TVD growing downward (Z axis is
  inverted so depth points down on screen but tick labels stay positive).
- **Equal aspect ratio** — the bounding box is sized to the data range, so
  trajectory shape isn't distorted.

When the plot opens, a one-line summary is also printed to the terminal:

```
Wellbore summary
----------------------------------------------------------------
Bore                   Class             MD        TVD      Reach  MaxInc
Deviated               deviated      6000.0     4875.2     2847.8    45.0
```

---

## Math: minimum curvature

For each pair of consecutive stations *(MD₁, I₁, A₁)* and *(MD₂, I₂, A₂)*:

```
ΔMD = MD₂ − MD₁
cos(DL) = cos(I₂ − I₁) − sin(I₁) · sin(I₂) · (1 − cos(A₂ − A₁))
RF      = (2 / DL) · tan(DL / 2)          # → 1 as DL → 0

ΔN   = (ΔMD / 2) · (sin I₁ cos A₁ + sin I₂ cos A₂) · RF
ΔE   = (ΔMD / 2) · (sin I₁ sin A₁ + sin I₂ sin A₂) · RF
ΔTVD = (ΔMD / 2) · (cos I₁ + cos I₂) · RF
DLS  = (DL in deg) · 100 / ΔMD            # dogleg severity, deg/100 unit
```

Same formulation used in commercial directional-survey software (Landmark
COMPASS, Halliburton Wellplan, Schlumberger Petrel) and the textbook
derivation in Bourgoyne et al.'s *Applied Drilling Engineering*. Conforms to
API RP 78.

A simple classification heuristic (`vertical` / `deviated` / `high-angle` /
`horizontal`) tags each bore based on terminal inclination and reach. It's
informational only — every trajectory is rendered identically regardless.

---

## Tests

```powershell
py tests\test_wellbore.py
```

Verifies the math on four closed-form cases (pure vertical, 90° build curve,
horizontal hold, classification). Expected output:

```
OK  pure vertical well
OK  90 deg build curve closed-form
OK  horizontal hold
OK  classification: horizontal

All wellbore math smoke tests passed.
```

---

## Project layout

```
well-viz-desktop/
├─ well_viz.py             # single-file app: math + parsing + plotting + CLI
├─ requirements.txt        # numpy, matplotlib
├─ README.md
├─ docs/
│  ├─ TECHNICAL_PAPER.md   # minimum-curvature derivation, references
│  ├─ CODE_GUIDE.md        # architecture, module-by-module walkthrough
│  └─ INTEGRATION.md       # library use, embedding, ports to JS/C#/MATLAB
├─ data/                   # bundled example surveys
│  ├─ vertical.csv
│  ├─ deviated.csv
│  ├─ horizontal.csv
│  ├─ extended-reach.csv
│  ├─ multilateral.json
│  ├─ sagd-pair.json
│  ├─ leg-main.csv         # multilateral split into one CSV per leg
│  ├─ leg-north.csv
│  ├─ leg-south.csv
│  ├─ plan-deviated.csv    # planned trajectory (for plan-vs-actual demo)
│  └─ actual-deviated.csv  # as-drilled with realistic drift
└─ tests/
   └─ test_wellbore.py     # closed-form regression tests
```

## Documentation

| Document                                       | What it covers                                                |
|------------------------------------------------|---------------------------------------------------------------|
| [README.md](README.md)                         | Install, run, mouse controls, input formats (you are here)    |
| [docs/TECHNICAL_PAPER.md](docs/TECHNICAL_PAPER.md) | The math: minimum-curvature derivation, coordinate systems, verification, references |
| [docs/CODE_GUIDE.md](docs/CODE_GUIDE.md)       | Architecture, every public function, extension points         |
| [docs/INTEGRATION.md](docs/INTEGRATION.md)     | Using as a library, headless rendering, REST patterns, ports to JavaScript / C# / MATLAB |

---

## Troubleshooting

**Plot window doesn't open, no error**: matplotlib needs a GUI backend.
On a fresh Windows install this usually works out of the box. If not:

```powershell
py -m pip install pyqt5
```

Then re-run. Or use `--save plot.png` to skip the window entirely and write
a PNG.

**`py` not recognized**: install Python from python.org with the
"Add to PATH" option checked. On macOS/Linux use `python3` instead.

**Numbers look squished**: the script forces equal aspect on the 3D box, but
on extremely elongated wells (e.g. a 22,000 ft ERW with 5,000 ft TVD) the
plot will be wide and shallow because *that's the actual shape of the well*.
Rotate to a top-down view to see the horizontal footprint, side view to see
the depth profile.
