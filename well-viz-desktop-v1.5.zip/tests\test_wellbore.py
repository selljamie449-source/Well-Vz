"""Closed-form smoke tests for the minimum-curvature math.

Run with:  py tests/test_wellbore.py
"""

from __future__ import annotations

import math
import os
import sys

# Allow running directly from inside tests/ without installing as a package.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from well_viz import compute_summary, minimum_curvature  # noqa: E402


def approx(actual: float, expected: float, tol: float, label: str) -> None:
    if abs(actual - expected) > tol:
        raise AssertionError(
            f"{label}: expected {expected} +/- {tol}, got {actual:.4f}"
        )


def test_pure_vertical() -> None:
    """Vertical well: TVD == MD; N and E stay at zero."""
    out = minimum_curvature([
        {"md": 0,    "inc": 0, "azi": 0},
        {"md": 1000, "inc": 0, "azi": 0},
        {"md": 2000, "inc": 0, "azi": 0},
        {"md": 3000, "inc": 0, "azi": 0},
    ])
    for s in out:
        approx(s["north"], 0.0, 1e-9, "vertical north")
        approx(s["east"],  0.0, 1e-9, "vertical east")
        approx(s["tvd"],   s["md"], 1e-9, "vertical TVD == MD")
    assert compute_summary(out)["classification"] == "vertical"
    print("OK  pure vertical well")


def test_quarter_circle_build() -> None:
    """90 deg build from vertical to horizontal-east in 1000 ft MD.

    Closed form: RF = (2/(pi/2))*tan(pi/4) = 4/pi
        dE   = 500 * 1 * RF = 2000/pi
        dTVD = 500 * 1 * RF = 2000/pi
        dN   = 0
        DLS  = 90 deg * 100 / 1000 ft = 9 deg/100ft
    """
    out = minimum_curvature([
        {"md": 0,    "inc": 0,  "azi": 0},
        {"md": 1000, "inc": 90, "azi": 90},
    ])
    last = out[1]
    expected = 2000.0 / math.pi
    approx(last["east"],  expected, 1e-3, "build dE")
    approx(last["tvd"],   expected, 1e-3, "build dTVD")
    approx(last["north"], 0.0,      1e-9, "build dN")
    approx(last["dls"],   9.0,      1e-6, "DLS deg/100ft on 1000 ft 90 deg dogleg")
    print("OK  90 deg build curve closed-form")


def test_horizontal_hold() -> None:
    """Horizontal section: TVD constant; east displacement equals delta-MD."""
    out = minimum_curvature([
        {"md": 0,    "inc": 90, "azi": 90},
        {"md": 1000, "inc": 90, "azi": 90},
    ])
    last = out[1]
    approx(last["tvd"],   0.0,    1e-9, "horizontal TVD stays at 0")
    approx(last["east"],  1000.0, 1e-9, "horizontal east displacement = delta-MD")
    approx(last["north"], 0.0,    1e-9, "horizontal north stays at 0")
    print("OK  horizontal hold")


def test_classification_horizontal() -> None:
    out = minimum_curvature([
        {"md": 0,    "inc": 0,  "azi": 0},
        {"md": 1500, "inc": 0,  "azi": 0},
        {"md": 2000, "inc": 90, "azi": 0},
        {"md": 4000, "inc": 90, "azi": 0},
    ])
    cls = compute_summary(out)["classification"]
    assert cls in ("horizontal", "high-angle"), f"expected horizontal/high-angle, got {cls}"
    print(f"OK  classification: {cls}")


def test_honors_file_supplied_tvd_dls() -> None:
    """When a station carries tvd/north/east/dls from the file, those are
    preserved verbatim instead of being overwritten by the computed result.

    We deliberately give the second station a TVD of 999 (which is wildly
    different from minimum curvature's ~636.6) and assert it survives.
    """
    out = minimum_curvature([
        {"md": 0,    "inc": 0,  "azi": 0},
        {"md": 1000, "inc": 90, "azi": 90,
         "tvd": 999.0, "north": 11.0, "east": 22.0, "dls": 33.0},
    ])
    s = out[1]
    approx(s["tvd"],   999.0, 1e-9, "file TVD preserved")
    approx(s["north"],  11.0, 1e-9, "file north preserved")
    approx(s["east"],   22.0, 1e-9, "file east preserved")
    approx(s["dls"],    33.0, 1e-9, "file DLS preserved")
    # And the source markers reflect the override.
    assert s["_source"]["tvd"]   == "file"
    assert s["_source"]["north"] == "file"
    assert s["_source"]["east"]  == "file"
    assert s["_source"]["dls"]   == "file"
    print("OK  honors file-supplied tvd/north/east/dls")


def test_fills_missing_optional_fields() -> None:
    """Stations without file-supplied values get their positions computed."""
    out = minimum_curvature([
        {"md": 0,    "inc": 0,  "azi": 0},
        {"md": 1000, "inc": 90, "azi": 90},  # no overrides
    ])
    s = out[1]
    import math as _m
    expected = 2000.0 / _m.pi
    approx(s["east"], expected, 1e-3, "computed east when file value absent")
    approx(s["tvd"],  expected, 1e-3, "computed TVD when file value absent")
    assert s["_source"]["tvd"]   == "computed"
    assert s["_source"]["east"]  == "computed"
    print("OK  computes when no file values present")


if __name__ == "__main__":
    test_pure_vertical()
    test_quarter_circle_build()
    test_horizontal_hold()
    test_classification_horizontal()
    test_honors_file_supplied_tvd_dls()
    test_fills_missing_optional_fields()
    print("\nAll wellbore math smoke tests passed.")
