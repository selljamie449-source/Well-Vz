@echo off
REM ===============================================================
REM  Well-Viz launcher — double-click to open the upload window.
REM  Uses pythonw so no console window flashes on screen.
REM  Sets cwd to this script's folder so the data/ examples load.
REM ===============================================================

cd /d "%~dp0"

REM Try pythonw first (no console window), then fall back to py.
where pythonw >nul 2>nul
if %errorlevel%==0 (
    start "" pythonw "well_viz.py" --gui
    exit /b
)

REM Fallback if pythonw isn't on PATH (rare): use py launcher.
where py >nul 2>nul
if %errorlevel%==0 (
    start "" py "well_viz.py" --gui
    exit /b
)

REM Last resort: plain python.
echo Python is not on PATH.
echo Please install Python from https://www.python.org/downloads/
echo Make sure to tick "Add Python to PATH" during install.
pause
