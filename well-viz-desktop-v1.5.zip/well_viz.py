"""
Well-Viz Desktop
================
Interactive 3D directional-survey visualizer. Reads an MD/Inc/Azi survey from
a CSV or JSON file, runs the industry-standard minimum-curvature method to
convert it into 3D Cartesian coordinates, and opens a matplotlib 3D window
you can rotate, zoom, and pan with the mouse.

Usage
-----
    # Auto-load the bundled "deviated" example
    py well_viz.py

    # Plot from your own survey file
    py well_viz.py path/to/survey.csv
    py well_viz.py path/to/multilateral.json

    # Plot a bundled example by name
    py well_viz.py --example horizontal
    py well_viz.py --example sagd-pair

    # List bundled examples
    py well_viz.py --list-examples

    # Read survey from stdin
    type survey.csv | py well_viz.py -

    # Other flags
    py well_viz.py --no-markers       # hide MD ring labels
    py well_viz.py --save out.png     # save a PNG instead of opening a window

Mouse controls
--------------
    Left-drag   : rotate the camera
    Right-drag  : zoom (or use the scroll wheel)
    Middle-drag : pan

Input formats
-------------
CSV: Header row required with columns md, inc, azi (case-insensitive).
     Lines starting with '#' are treated as comments.

         md,inc,azi
         0,0,0
         1500,0,0
         2500,45,90
         6000,45,90

JSON: Either an array of station dicts:

         [ {"md": 0, "inc": 0, "azi": 0}, ... ]

      Or a multi-bore envelope (multilateral / SAGD pair):

         {
           "bores": [
             { "name": "Main",  "color": "#38bdf8", "stations": [...] },
             { "name": "Lat 1", "color": "#22c55e", "stations": [...] }
           ]
         }
"""

from __future__ import annotations

import argparse
import csv
import io
import json
import math
import os
import re
import sys
from pathlib import Path
from typing import Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np


# ---------------------------------------------------------------------------
# Windows DPI awareness — must be set BEFORE numpy/matplotlib pull in any
# native windowing. Otherwise matplotlib's Tk backend later flips the process
# to per-monitor DPI aware mid-run, and any tkinter window opened after that
# renders fonts at native pixels (= visibly smaller text on HiDPI screens).
# Calling this at import time makes every window — tk and matplotlib alike —
# agree on the DPI from the very first render.
# ---------------------------------------------------------------------------
def _enable_dpi_awareness() -> None:
    if sys.platform != "win32":
        return
    try:
        from ctypes import windll
        # PROCESS_SYSTEM_DPI_AWARE = 1 (safer / more compatible than 2)
        windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        try:
            from ctypes import windll
            windll.user32.SetProcessDPIAware()
        except Exception:
            pass


_enable_dpi_awareness()


import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401 — required to register 3D projection


# ===========================================================================
# 1. Minimum-curvature trajectory math
# ===========================================================================
#
# For each consecutive pair of survey stations (MD1, Inc1, Azi1) -> (MD2, Inc2, Azi2)
# the borehole is assumed to follow a circular arc on a sphere. The closed-form
# equations are:
#
#     ΔMD       = MD2 − MD1
#     cos(DL)   = cos(I2 − I1) − sin(I1)·sin(I2)·(1 − cos(A2 − A1))
#     RF        = (2 / DL) · tan(DL / 2)        # → 1 as DL → 0
#
#     ΔNorth = (ΔMD/2) · (sin I1 cos A1 + sin I2 cos A2) · RF
#     ΔEast  = (ΔMD/2) · (sin I1 sin A1 + sin I2 sin A2) · RF
#     ΔTVD   = (ΔMD/2) · (cos I1 + cos I2) · RF
#     DLS    = (DL in degrees) · 100 / ΔMD       # dogleg severity per 100 unit
#
# Same formulation used in Landmark COMPASS / Schlumberger Petrel / API RP 78.


def _dogleg_rad(inc1: float, azi1: float, inc2: float, azi2: float) -> float:
    i1, i2 = math.radians(inc1), math.radians(inc2)
    a1, a2 = math.radians(azi1), math.radians(azi2)
    cos_dl = math.cos(i2 - i1) - math.sin(i1) * math.sin(i2) * (1 - math.cos(a2 - a1))
    # Clamp for floating-point drift outside [-1, 1] when stations are colinear.
    return math.acos(max(-1.0, min(1.0, cos_dl)))


def _ratio_factor(dl: float) -> float:
    """Minimum-curvature ratio factor. RF -> 1 as DL -> 0."""
    if dl < 1e-9:
        return 1.0
    return (2.0 / dl) * math.tan(dl / 2.0)


def minimum_curvature(
    stations: Sequence[Mapping[str, float]],
    surface_x: float = 0.0,
    surface_y: float = 0.0,
    surface_z: float = 0.0,
) -> List[dict]:
    """Apply minimum curvature to a sequence of (md, inc, azi) stations.

    If a station also carries `tvd`, `north`, `east`, or `dls` (e.g. read
    from an industry export that already contains them), those values are
    preserved verbatim — they are NOT overwritten by the computed result.
    This matters because TVD and DLS reported by the user's planning
    software (Compass / WellPlan / Petrel / etc.) may be the engineering
    team's source of truth, and silent recomputation here would introduce
    discrepancies with downstream workflows.

    The computed position is always carried in the running accumulator so
    that subsequent stations remain consistent — overrides only affect the
    *reported* values for the station that supplied them, not the math for
    the next segment. Each output station carries a `_source` dict telling
    you which fields were supplied vs. computed:

        s["_source"] == {
            "tvd": "file" | "computed",
            "north": "file" | "computed",
            "east": "file" | "computed",
            "dls": "file" | "computed",
        }
    """
    if not stations:
        return []

    sorted_stations = sorted(stations, key=lambda s: float(s["md"]))

    def _maybe(s, key):
        v = s.get(key)
        return float(v) if v is not None else None

    # ---- station 0 -------------------------------------------------------
    first = sorted_stations[0]
    f_tvd, f_n, f_e, f_dls = (_maybe(first, k) for k in ("tvd", "north", "east", "dls"))

    out: List[dict] = [
        {
            "md":  float(first["md"]),
            "inc": float(first["inc"]),
            "azi": float(first["azi"]),
            "north": f_n if f_n is not None else surface_y,
            "east":  f_e if f_e is not None else surface_x,
            "tvd":   f_tvd if f_tvd is not None else surface_z,
            "dls":   f_dls if f_dls is not None else 0.0,
            "horizontalDisplacement": 0.0,
            "_source": {
                "tvd":   "file" if f_tvd is not None else "computed",
                "north": "file" if f_n   is not None else "computed",
                "east":  "file" if f_e   is not None else "computed",
                "dls":   "file" if f_dls is not None else "computed",
            },
            # internal running accumulators (computed via min curvature)
            "_calc_north": surface_y,
            "_calc_east":  surface_x,
            "_calc_tvd":   surface_z,
        }
    ]
    out[0]["horizontalDisplacement"] = math.sqrt(out[0]["north"]**2 + out[0]["east"]**2)

    # ---- subsequent stations --------------------------------------------
    for i in range(1, len(sorted_stations)):
        prev = out[i - 1]
        curr = sorted_stations[i]
        md_curr  = float(curr["md"])
        inc_curr = float(curr["inc"])
        azi_curr = float(curr["azi"])

        d_md = md_curr - prev["md"]
        if d_md < 0:
            raise ValueError(
                f"Survey MD must be monotonically increasing. "
                f"Station {i} has MD {md_curr} < previous {prev['md']}."
            )

        dl = _dogleg_rad(prev["inc"], prev["azi"], inc_curr, azi_curr)
        rf = _ratio_factor(dl)
        i1, i2 = math.radians(prev["inc"]), math.radians(inc_curr)
        a1, a2 = math.radians(prev["azi"]), math.radians(azi_curr)

        d_north = (d_md / 2) * (math.sin(i1) * math.cos(a1) + math.sin(i2) * math.cos(a2)) * rf
        d_east  = (d_md / 2) * (math.sin(i1) * math.sin(a1) + math.sin(i2) * math.sin(a2)) * rf
        d_tvd   = (d_md / 2) * (math.cos(i1) + math.cos(i2)) * rf

        # Computed (minimum-curvature) cumulative position. Stays running
        # regardless of any per-station file overrides so later segments
        # remain consistent with the previous *computed* point.
        calc_north = prev["_calc_north"] + d_north
        calc_east  = prev["_calc_east"]  + d_east
        calc_tvd   = prev["_calc_tvd"]   + d_tvd
        calc_dls   = (math.degrees(dl) * 100.0 / d_md) if d_md > 0 else 0.0

        # File-supplied overrides for this station (if any).
        f_tvd, f_n, f_e, f_dls = (_maybe(curr, k) for k in ("tvd", "north", "east", "dls"))

        north = f_n   if f_n   is not None else calc_north
        east  = f_e   if f_e   is not None else calc_east
        tvd   = f_tvd if f_tvd is not None else calc_tvd
        dls   = f_dls if f_dls is not None else calc_dls

        out.append({
            "md":  md_curr,
            "inc": inc_curr,
            "azi": azi_curr,
            "north": north,
            "east":  east,
            "tvd":   tvd,
            "dls":   dls,
            "horizontalDisplacement": math.sqrt(north * north + east * east),
            "_source": {
                "tvd":   "file" if f_tvd is not None else "computed",
                "north": "file" if f_n   is not None else "computed",
                "east":  "file" if f_e   is not None else "computed",
                "dls":   "file" if f_dls is not None else "computed",
            },
            "_calc_north": calc_north,
            "_calc_east":  calc_east,
            "_calc_tvd":   calc_tvd,
        })

    return out


def densify(stations: List[dict], step_md: float = 50.0) -> List[dict]:
    """Insert interpolated stations every `step_md` along the trajectory.

    Pure visual smoothing: re-runs minimum curvature on sub-sampled (md, inc, azi)
    values so the rendered line follows the assumed circular-arc geometry between
    surveyed stations instead of taking visible chord segments. Math output for
    the original station locations is unchanged.
    """
    if len(stations) < 2:
        return stations

    raw = [{"md": s["md"], "inc": s["inc"], "azi": s["azi"]} for s in stations]
    dense: List[dict] = []
    for a, b in zip(raw[:-1], raw[1:]):
        dense.append(a)
        gap = b["md"] - a["md"]
        if gap <= step_md:
            continue
        n = int(gap // step_md)
        for k in range(1, n + 1):
            t = (k * step_md) / gap
            if t >= 1.0:
                break
            dense.append(
                {
                    "md": a["md"] + t * gap,
                    "inc": a["inc"] + t * (b["inc"] - a["inc"]),
                    "azi": _interp_azi(a["azi"], b["azi"], t),
                }
            )
    dense.append(raw[-1])
    return minimum_curvature(dense)


def _interp_azi(a: float, b: float, t: float) -> float:
    """Interpolate azimuth taking the short way around the compass (e.g. 350° -> 10°)."""
    diff = ((b - a + 540.0) % 360.0) - 180.0
    return (a + diff * t) % 360.0


def compute_summary(stations: List[dict]) -> dict:
    """Aggregate metrics + simple well-type classification."""
    if not stations:
        return {
            "stationCount": 0, "totalMd": 0.0, "totalTvd": 0.0,
            "horizontalReach": 0.0, "maxInclination": 0.0, "maxDls": 0.0,
            "classification": "unknown",
        }
    last = stations[-1]
    max_inc = max(s["inc"] for s in stations)
    max_dls = max(s["dls"] for s in stations)
    reach = max(s["horizontalDisplacement"] for s in stations)
    if max_inc >= 80:
        cls = "horizontal" if reach > last["tvd"] else "high-angle"
    elif max_inc >= 30:
        cls = "deviated"
    else:
        cls = "vertical"
    return {
        "stationCount": len(stations),
        "totalMd": last["md"],
        "totalTvd": last["tvd"],
        "horizontalReach": reach,
        "maxInclination": max_inc,
        "maxDls": max_dls,
        "classification": cls,
    }


# ===========================================================================
# 2. CSV + JSON input parsing
# ===========================================================================

# Header tokens we recognise. Required vs optional is enforced separately
# by parse_csv — md/inc/azi must be present, the rest are honoured when found
# and computed via minimum curvature when absent.
_HEADER_ALIASES = {
    # Required
    "md":    {"md", "measureddepth", "depth"},
    "inc":   {"inc", "inclination", "incl"},
    "azi":   {"azi", "azimuth", "az"},
    # Optional — preserved verbatim when supplied so values reported by the
    # user's planning software (Compass / WellPlan / Petrel / etc.) round-trip
    # through Well-Viz unchanged. Industry conventions like "N.offset" (= delta
    # from wellhead) and "DLS" with metric °/30 m units are kept as-is.
    "tvd":   {"tvd", "truevertdepth", "truevertical", "truedepth"},
    "north": {"noffset", "northoffset", "deltan", "deltanorth", "northdisplacement"},
    "east":  {"eoffset", "eastoffset", "deltae", "deltaeast", "eastdisplacement"},
    "dls":   {"dls", "doglegseverity", "dogleg"},
}

_REQUIRED_HEADERS = ("md", "inc", "azi")
_OPTIONAL_HEADERS = ("tvd", "north", "east", "dls")


def _normalize_header(h: str) -> str:
    """Aggressively normalise a CSV header for alias matching.

    Strips parenthesized unit annotations and all separator characters so
    industry exports like "MD (m)", "Inc (degrees)", "Azimuth ( degree)",
    "N.offset (m)" all reduce to the bare token ("md", "inc", "azimuth",
    "noffset").
    """
    s = h.strip().lower()
    s = re.sub(r"\([^)]*\)", "", s)        # drop "(m)", "(degrees)", "(degree/30m)" etc.
    s = re.sub(r"\[[^\]]*\]", "", s)       # drop bracketed annotations too
    s = re.sub(r"[\s_\-.]", "", s)         # strip whitespace, _, -, .
    return s


def parse_csv(text: str) -> List[dict]:
    """Parse a CSV survey.

    Required columns: md, inc, azi (with industry aliases — see _HEADER_ALIASES).
    Optional columns honoured when found:
        - tvd            (preferred unit-agnostic; preserved as-is)
        - N.offset       (north displacement from wellhead)
        - E.offset       (east displacement from wellhead)
        - DLS            (dogleg severity, preserved with whatever unit the
                          file uses — typically °/100 ft in imperial, °/30 m
                          in metric)

    Other columns (Northing, Easting, Vs, T.face, B.rate, Dist to plan,
    High to plan, Role to plan, SS elevation, etc.) are silently ignored.
    """
    lines = [
        ln for ln in (raw.strip() for raw in text.replace("\r\n", "\n").split("\n"))
        if ln and not ln.startswith("#")
    ]
    if len(lines) < 2:
        raise ValueError("CSV must contain a header row and at least one station.")

    reader = csv.reader(io.StringIO("\n".join(lines)))
    header = [_normalize_header(c) for c in next(reader)]

    idx = {}
    for key, aliases in _HEADER_ALIASES.items():
        normalized = {re.sub(r"[\s_\-.]", "", a) for a in aliases}
        found = next((i for i, h in enumerate(header) if h in normalized), -1)
        if found != -1:
            idx[key] = found
        elif key in _REQUIRED_HEADERS:
            raise ValueError(
                f'CSV is missing required column "{key}". '
                f'Found columns: {", ".join(header)}'
            )
        # Optional columns simply remain absent from idx.

    def _maybe_float(row, k):
        """Return float(row[idx[k]]) if column k is present and the cell parses,
        else None. Empty cells, '-', 'NA', 'N/A' are treated as missing."""
        if k not in idx:
            return None
        try:
            cell = row[idx[k]].strip()
        except IndexError:
            return None
        if not cell or cell.lower() in {"-", "na", "n/a", "nan", "null"}:
            return None
        try:
            return float(cell)
        except ValueError:
            return None

    stations: List[dict] = []
    for row_no, row in enumerate(reader, start=2):
        try:
            station = {
                "md":  float(row[idx["md"]]),
                "inc": float(row[idx["inc"]]),
                "azi": float(row[idx["azi"]]),
            }
        except (ValueError, IndexError) as exc:
            raise ValueError(f"Row {row_no} has non-numeric or missing MD/Inc/Azi values.") from exc
        for opt in _OPTIONAL_HEADERS:
            v = _maybe_float(row, opt)
            if v is not None:
                station[opt] = v
        stations.append(station)
    return stations


def parse_json(text: str) -> dict:
    """Parse a JSON survey payload.

    Returns {"bores": [{name, color?, stations, surfaceX?, surfaceY?, surfaceZ?}, ...]}.
    Single-bore arrays are wrapped in a one-element `bores` list.
    """
    data = json.loads(text) if isinstance(text, str) else text

    if isinstance(data, list):
        return {"bores": [{"name": "Wellbore", "stations": _normalize_stations(data)}]}

    if isinstance(data, dict) and isinstance(data.get("bores"), list):
        bores = []
        for b in data["bores"]:
            bore = {
                "name": b.get("name") or "Wellbore",
                "stations": _normalize_stations(b.get("stations"), label=b.get("name")),
            }
            # Pass through optional cosmetic / placement fields when present.
            # `role` is "planned" or "actual" — controls rendering style only
            # (see plot_wells). All other roles fall back to "actual".
            for k in ("color", "role", "surfaceX", "surfaceY", "surfaceZ"):
                if b.get(k) is not None:
                    bore[k] = b[k]
            bores.append(bore)
        return {"bores": bores, "meta": data.get("meta", {})}

    raise ValueError(
        'JSON must be either an array of stations or {"bores": [{"name", "stations"}]}.'
    )


_JSON_FIELD_ALIASES = {
    "md":    ("md", "MD", "measuredDepth"),
    "inc":   ("inc", "INC", "inclination"),
    "azi":   ("azi", "AZI", "azimuth"),
    "tvd":   ("tvd", "TVD"),
    "north": ("north", "N", "Noffset", "nOffset", "n_offset"),
    "east":  ("east", "E", "Eoffset", "eOffset", "e_offset"),
    "dls":   ("dls", "DLS", "doglegSeverity"),
}


def _pick(d: dict, keys: Tuple[str, ...]):
    for k in keys:
        if k in d and d[k] is not None:
            return d[k]
    return None


def _normalize_stations(arr, label: Optional[str] = None) -> List[dict]:
    """JSON counterpart of parse_csv's row loop. Same required vs optional split."""
    if not isinstance(arr, list):
        suffix = f' in bore "{label}"' if label else ""
        raise ValueError(f"Expected an array of stations{suffix}.")
    out = []
    for i, s in enumerate(arr):
        try:
            md  = float(_pick(s, _JSON_FIELD_ALIASES["md"]))
            inc = float(_pick(s, _JSON_FIELD_ALIASES["inc"]))
            azi = float(_pick(s, _JSON_FIELD_ALIASES["azi"]))
        except (TypeError, ValueError) as exc:
            raise ValueError(f"Station {i + 1} is missing numeric md/inc/azi.") from exc
        station = {"md": md, "inc": inc, "azi": azi}
        for opt in _OPTIONAL_HEADERS:
            v = _pick(s, _JSON_FIELD_ALIASES[opt])
            if v is not None:
                try:
                    station[opt] = float(v)
                except (TypeError, ValueError):
                    pass  # silently drop malformed optional values
        out.append(station)
    return out


def load_survey(source: str) -> List[dict]:
    """Load a survey from a file path. Returns a list of bores."""
    p = Path(source)
    if not p.is_file():
        raise FileNotFoundError(f"Survey file not found: {source}")

    text = p.read_text(encoding="utf-8")
    if p.suffix.lower() == ".json":
        parsed = parse_json(text)
        return parsed["bores"]
    stations = parse_csv(text)
    return [{"name": p.stem.replace("_", " ").replace("-", " ").title(), "stations": stations}]


def load_from_text(text: str, format: str = "csv") -> List[dict]:
    """Load a survey from a raw text payload (used for stdin)."""
    text = text.strip()
    if not text:
        raise ValueError("Empty input.")
    # Auto-detect JSON if the payload starts with { or [.
    if text[0] in "{[" or format == "json":
        parsed = parse_json(text)
        return parsed["bores"]
    stations = parse_csv(text)
    return [{"name": "Wellbore", "stations": stations}]


def load_legs(
    paths: Sequence[str],
    names: Optional[Sequence[str]] = None,
    colors: Optional[Sequence[str]] = None,
) -> List[dict]:
    """Load multiple files as separate legs of a multilateral well.

    Each file is expected to contain a complete survey from surface to the toe
    of that leg — the standard format directional surveyors deliver one file
    per lateral. The shared upper section will naturally overlap in the 3D plot
    because every leg starts at MD = 0.

    A leg file may be:
        - A CSV (treated as a single bore, that leg).
        - A JSON list of stations (single bore).
        - A JSON multi-bore envelope (every bore inside it is appended as legs).

    `names` and `colors`, if provided, override per-leg labels and colours.
    They are applied positionally to the *legs in load order* (a multi-bore
    JSON file expands to multiple legs).
    """
    if not paths:
        raise ValueError("load_legs requires at least one path.")

    legs: List[dict] = []
    for path in paths:
        loaded = load_survey(path)  # returns list[dict] (1 or more bores)
        for bore in loaded:
            legs.append(bore)

    # Apply --names / --colors overrides positionally.
    if names:
        for i, override in enumerate(names):
            if i < len(legs) and override:
                legs[i]["name"] = override
    if colors:
        for i, override in enumerate(colors):
            if i < len(legs) and override:
                legs[i]["color"] = override

    # If the user didn't override names and the auto-generated ones came from
    # file stems, give them "L1", "L2", ... style labels by default — that's
    # closer to driller convention than the title-cased filenames.
    if not names:
        for i, leg in enumerate(legs):
            if leg.get("name") and any(c.isalpha() for c in leg["name"]):
                # Filename-derived name was set; keep it but prefix the leg number.
                if not leg["name"].lower().startswith(("l", "leg")):
                    leg["name"] = f"L{i + 1} — {leg['name']}"
            else:
                leg["name"] = f"L{i + 1}"
    return legs


def load_plan_vs_actual(
    planned_paths: Sequence[str] = (),
    actual_paths: Sequence[str] = (),
    names: Optional[Sequence[str]] = None,
    colors: Optional[Sequence[str]] = None,
) -> List[dict]:
    """Load planned and actual surveys for side-by-side comparison.

    Each `planned_paths[i]` is paired with `actual_paths[i]` (positional).
    The pair shares one colour (`colors[i]` if given, else the palette
    default) and one name (`names[i]` if given). The planned bore is tagged
    with `role="planned"` and rendered dashed + translucent by `plot_wells`;
    the actual is tagged `role="actual"` (the default) and rendered solid.

    The two lists may be different lengths — surplus plans without actuals
    (or actuals without plans) render alone with their own colour.

    Returned ordering: pair_i.planned, pair_i.actual, pair_{i+1}.planned, ...
    so the legend reads naturally "Main (planned), Main (actual), Lateral 1
    (planned), Lateral 1 (actual)".
    """
    if not planned_paths and not actual_paths:
        raise ValueError("load_plan_vs_actual requires at least one --planned or --actual path.")

    # Expand each path into its bores (a JSON file may yield multiple).
    def _expand(paths: Sequence[str]) -> List[List[dict]]:
        return [load_survey(p) for p in paths]

    plan_files = _expand(planned_paths)
    actual_files = _expand(actual_paths)

    # We pair file-by-file. If a single JSON file inside one slot expands to
    # multiple bores (e.g. a multilateral packaged as one JSON), each becomes
    # its own pair index — keeping the pairing semantics straightforward.
    plan_legs: List[dict] = [bore for legs in plan_files for bore in legs]
    actual_legs: List[dict] = [bore for legs in actual_files for bore in legs]

    pair_count = max(len(plan_legs), len(actual_legs))
    ordered: List[dict] = []
    for i in range(pair_count):
        color = (colors[i] if colors and i < len(colors) and colors[i]
                 else DEFAULT_COLORS[i % len(DEFAULT_COLORS)])
        name = (names[i] if names and i < len(names) and names[i] else None)

        if i < len(plan_legs):
            p = plan_legs[i]
            p["role"] = "planned"
            p["color"] = color
            if name:
                p["name"] = name
            elif p.get("name"):
                p["name"] = p["name"]  # keep filename-derived
            else:
                p["name"] = f"Pair {i + 1}"
            ordered.append(p)

        if i < len(actual_legs):
            a = actual_legs[i]
            a["role"] = "actual"
            a["color"] = color
            if name:
                a["name"] = name
            elif a.get("name"):
                a["name"] = a["name"]
            else:
                a["name"] = f"Pair {i + 1}"
            ordered.append(a)

    return ordered


# ===========================================================================
# 3. Matplotlib 3D rendering
# ===========================================================================

# Bore palette — picked to read well on a white background. The originals
# were tuned for a dark theme, so the blues/greens here are a touch deeper
# and the yellows are dropped (too pale on white) in favour of red/teal.
DEFAULT_COLORS = [
    "#0284c7",  # ocean blue
    "#ea580c",  # burnt orange
    "#15803d",  # forest green
    "#7c3aed",  # violet
    "#be123c",  # crimson
    "#0f766e",  # teal
]

# Light-theme palette constants — used throughout plot_wells.
_BG          = "#ffffff"
_PANE        = "#f6f7fb"   # very light grey for axis panes
_GRID        = "#cbd5e1"   # soft grey gridlines
_FG          = "#0f172a"   # nearly-black for primary text
_FG_DIM      = "#475569"   # mid-grey for secondary text / footer
_WELLHEAD    = "#f59e0b"   # amber — still pops on white
_MD_LABEL    = "#1e293b"   # dark slate for MD ring labels
_MD_DOT      = "#64748b"   # mid-grey for MD scatter markers
_LEGEND_BG   = "#ffffff"
_LEGEND_EDGE = "#94a3b8"


def _equal_3d_box(ax, x_all, y_all, z_all, *, mode: str = "cubic") -> None:
    """Set axis limits + box aspect so the well stays in the frame.

    Two modes:
      "cubic" — every axis spans the same range and the box is a unit cube.
                Best for rotation: the well stays in view at every angle,
                even if the data is much longer in one direction.
      "fill" —  Box aspect matches the actual data extents, so the well
                fills the panel as completely as possible. Best for the
                Maximise-3D view where you want every available pixel of
                wellbore detail; rotation may push edges out of frame
                (press 'r' to recover).
    """
    if not (x_all and y_all and z_all):
        return
    cx = (max(x_all) + min(x_all)) / 2.0
    cy = (max(y_all) + min(y_all)) / 2.0
    cz = (max(z_all) + min(z_all)) / 2.0
    sx = max(max(x_all) - min(x_all), 1.0)
    sy = max(max(y_all) - min(y_all), 1.0)
    sz = max(max(z_all) - min(z_all), 1.0)

    if mode == "fill":
        # Symmetric limits sized to each axis individually, plus a small pad.
        pad = 1.05
        hx = sx / 2.0 * pad
        hy = sy / 2.0 * pad
        hz = sz / 2.0 * pad
        ax.set_xlim3d(cx - hx, cx + hx)
        ax.set_ylim3d(cy - hy, cy + hy)
        ax.set_zlim3d(cz + hz, cz - hz)  # inverted (depth down)
        try:
            ax.set_box_aspect((sx, sy, sz))
        except (AttributeError, TypeError):
            pass
    else:  # cubic — default for stable rotation
        # Generous padding (×1.25) so the wellbore sits comfortably inside
        # the box with margin on every side, even after rotation.
        half = max(sx, sy, sz) / 2.0 * 1.25
        ax.set_xlim3d(cx - half, cx + half)
        ax.set_ylim3d(cy - half, cy + half)
        ax.set_zlim3d(cz + half, cz - half)
        try:
            ax.set_box_aspect((1, 1, 1))
        except (AttributeError, TypeError):
            pass

    # Orthographic — predictable rotation, no perspective skew.
    try:
        ax.set_proj_type("ortho")
    except AttributeError:
        pass


def plot_wells(
    bores: List[dict],
    *,
    densify_step: float = 50.0,
    show_md_markers: bool = True,
    title: Optional[str] = None,
    save_path: Optional[str] = None,
    color_by_dls: bool = False,
    show_plan_view: bool = True,
    show_section_view: bool = True,
    show_deviation_panel: bool = True,
    allow_home: bool = False,
) -> bool:
    """Render the bores. Returns True if the user clicked the Home button
    (signalling the caller to re-open the upload screen)."""
    """Render one or more bores in a matplotlib window.

    Layout (computed dynamically based on what's present):
      • Main 3D view (always shown)
      • Top-down plan view inset (East vs North), shown if `show_plan_view`
      • Vertical section view inset (Horiz vs TVD), shown if `show_section_view`
      • Deviation-vs-MD panel below the 3D, shown when at least one
        (planned, actual) pair is present and `show_deviation_panel` is on

    `color_by_dls=True` switches the trajectory line from per-bore colour
    to a continuous DLS-based colour ramp, with a shared colourbar. Plan-vs-
    actual line styles (dashed vs solid) are retained so the two are still
    distinguishable.
    """
    # ------------------------------------------------------------------- prep
    prepared, summaries, stations_per_bore = _prepare_bores(bores, densify_step)

    # Detect plan/actual pairs (matched by display name).
    pairs = _find_plan_actual_pairs(prepared)
    deviations = [(p["plan"]["name"], _compute_deviation(p["plan"], p["actual"]))
                  for p in pairs] if (pairs and show_deviation_panel) else []
    has_dev_panel = len(deviations) > 0

    # ------------------------------------------------------------ figure & axes
    # Lower interactive DPI = fewer pixels per frame = smoother drag.
    # Saved PNGs override this with dpi=200 on savefig, so quality is
    # only sacrificed during live interaction.
    fig = plt.figure(
        figsize=(15, 9) if (show_plan_view or show_section_view) else (12, 8),
        dpi=100 if not save_path else 120,
    )
    fig.canvas.manager.set_window_title("Well-Viz 3D")
    fig.patch.set_facecolor(_BG)

    # In-figure controls (menu dropdown). Lives in `_controls` so the
    # toggle handlers below can mutate the displayed state.
    _controls = {
        "menu_open": False,
        "menu_items": [],
        "dls_on":      color_by_dls,
        "dls_btn":     None,
        "dls_cbar_ax": None,
        "md_on":       show_md_markers,
        "md_btn":      None,
        "plan_on":     show_plan_view,
        "plan_btn":    None,
        "section_on":  show_section_view,
        "section_btn": None,
        "dev_on":      show_deviation_panel,
        "dev_btn":     None,
        "devleg_on":   True,
        "devleg_btn":  None,
        "legend_on":   True,
        "legend_btn":  None,
        "home_clicked": False,
        "fullscreen":   False,
        "fs_btn":       None,
        "view":        (20.0, -60.0),  # (elev, azim) — current camera preset
        "dark":        False,          # immersive dark theme (Maximise 3D)
        "suptitle":    None,
        "footer":      [],
        "data_extent": None,
    }

    ax3d, ax_plan, ax_sec, ax_dev = _build_layout(
        fig,
        show_insets=(show_plan_view or show_section_view),
        show_plan=show_plan_view,
        show_section=show_section_view,
        show_dev=has_dev_panel,
    )

    # -------------------------------------------------------- DLS color limits
    dls_norm = None
    dls_cmap = None
    if color_by_dls:
        all_dls = [s["dls"] for b in prepared for s in b["fine"] if s["dls"] is not None]
        if all_dls:
            import matplotlib as _mpl
            from matplotlib.colors import Normalize
            dls_cmap = _mpl.colormaps["plasma"]
            # 95th-percentile cap so a single high-DLS outlier doesn't wash out the rest.
            top = float(np.percentile(all_dls, 95))
            dls_norm = Normalize(vmin=0.0, vmax=max(top, 1e-6))

    # --------------------------------------------------------------- 3D panel
    _draw_3d(ax3d, prepared, color_by_dls=color_by_dls,
             dls_cmap=dls_cmap, dls_norm=dls_norm,
             show_md_markers=show_md_markers)

    # Title sits at the very top of the figure (above the legend).
    _controls["suptitle"] = fig.suptitle(
        title or _default_title(summaries),
        color=_FG, fontsize=10, fontweight="bold", y=0.995)

    # Footer hint — three columns at the very bottom of the canvas, well
    # below the 3-D axes labels so nothing collides.
    _hint_kwargs = dict(color=_FG_DIM, fontsize=7.5, va="bottom")
    _controls["footer"] = [
        fig.text(0.20, 0.025, "Left-drag · rotate",               ha="center", **_hint_kwargs),
        fig.text(0.50, 0.025, "Scroll · zoom (axes follow)",      ha="center", **_hint_kwargs),
        fig.text(0.80, 0.025, "'r' or double-click · reset view", ha="center", **_hint_kwargs),
    ]

    # --------------------------------------------------------- inset panels
    if ax_plan is not None:
        _draw_plan_view(ax_plan, prepared)
    if ax_sec is not None:
        _draw_section_view(ax_sec, prepared)

    # ----------------------------------------------------- deviation panel
    if ax_dev is not None:
        _draw_deviation_panel(ax_dev, deviations, prepared)

    # ---------------------------------------------- shared DLS colourbar
    def _add_colorbar(cmap, norm):
        from matplotlib.colorbar import ColorbarBase
        tcol = "#9fb3cc" if _controls["dark"] else _FG_DIM
        cbar_ax = fig.add_axes([0.965, 0.20, 0.008, 0.60])
        ColorbarBase(cbar_ax, cmap=cmap, norm=norm)
        cbar_ax.set_title("DLS\n°/30m", color=tcol, fontsize=7.5, pad=6)
        cbar_ax.tick_params(colors=tcol, labelsize=7)
        return cbar_ax

    if color_by_dls and dls_norm is not None:
        _controls["dls_cbar_ax"] = _add_colorbar(dls_cmap, dls_norm)

    # ------------------------------------------------------------- summary
    _print_text_summary(summaries, stations_per_bore=stations_per_bore,
                        deviations=deviations)

    # ============================================================
    # Menu dropdown — consolidates Home + DLS toggle behind one ≡
    # button so the canvas stays clean.
    # ============================================================
    if not save_path:
        from matplotlib.widgets import Button

        def _style_pill(btn, ax, bg, hover, text_color, border):
            btn.label.set_color(text_color)
            btn.label.set_fontsize(9)
            btn.label.set_fontweight("bold")
            btn.hovercolor = hover
            for spine in ax.spines.values():
                spine.set_edgecolor(border)
                spine.set_linewidth(0.8)

        # ---- DLS toggle handler --------------------------------------
        def _compute_dls():
            all_dls = [s["dls"] for b in prepared for s in b["fine"]
                       if s["dls"] is not None]
            if not all_dls:
                return None, None
            import matplotlib as _mpl
            from matplotlib.colors import Normalize
            cmap = _mpl.colormaps["plasma"]
            top = float(np.percentile(all_dls, 95))
            norm = Normalize(vmin=0.0, vmax=max(top, 1e-6))
            return cmap, norm

        def _redraw_3d():
            """Re-render just the 3-D axes using the current control state."""
            cmap, norm = (_compute_dls()
                          if _controls["dls_on"] else (None, None))
            if _controls["dls_on"] and cmap is None:
                _controls["dls_on"] = False  # No DLS data — silently disable.

            box_mode = "fill" if _controls["fullscreen"] else "cubic"
            dark = _controls["dark"]
            ax3d.clear()
            _draw_3d(ax3d, prepared,
                     color_by_dls=_controls["dls_on"],
                     dls_cmap=cmap, dls_norm=norm,
                     show_md_markers=_controls["md_on"],
                     box_mode=box_mode, dark=dark)
            # Recolour figure-level text (suptitle + footer hints) for theme.
            _txt = "#e8eef6" if dark else _FG
            _txt_dim = "#9fb3cc" if dark else _FG_DIM
            if _controls["suptitle"] is not None:
                _controls["suptitle"].set_color(_txt)
            for _ft in _controls["footer"]:
                _ft.set_color(_txt_dim)
            # Preserve the user's chosen camera preset across re-renders.
            ev, az = _controls["view"]
            ax3d.view_init(elev=ev, azim=az)
            # Preserve legend on/off state too.
            if not _controls["legend_on"]:
                for L in getattr(fig, "legends", []):
                    L.set_visible(False)

            if _controls["dls_cbar_ax"] is not None:
                _controls["dls_cbar_ax"].remove()
                _controls["dls_cbar_ax"] = None
            if _controls["dls_on"] and norm is not None:
                _controls["dls_cbar_ax"] = _add_colorbar(cmap, norm)

        def _set_dls(on: bool):
            _controls["dls_on"] = on
            _redraw_3d()
            if _controls["dls_btn"] is not None:
                _controls["dls_btn"].label.set_text(
                    ("✓  " if _controls["dls_on"] else "     ") + "DLS heatmap"
                )
            fig.canvas.draw_idle()

        # ---- Menu toggle --------------------------------------------
        def _set_menu(open_: bool):
            _controls["menu_open"] = open_
            for ax, _btn in _controls["menu_items"]:
                ax.set_visible(open_)
            menu_btn.label.set_text("≡  Menu  ▾" if not open_ else "≡  Menu  ▴")
            fig.canvas.draw_idle()

        # ---- Top-left toolbar: [⌂ Home] [≡ Menu ▾] [View ▾] -------------
        # Home is a dedicated, always-visible button (not buried in the
        # menu) so it's never lost. Shown only when launched from the
        # upload screen (allow_home).
        _tb_x = 0.005
        if allow_home:
            home_ax = fig.add_axes([_tb_x, 0.955, 0.065, 0.038])
            home_btn = Button(home_ax, "⌂ Home",
                              color="#dbeafe", hovercolor="#bfdbfe")
            _style_pill(home_btn, home_ax, "#dbeafe", "#bfdbfe",
                        "#1e3a8a", "#1e40af")

            def _go_home_btn(_e):
                _controls["home_clicked"] = True
                plt.close(fig)
            home_btn.on_clicked(_go_home_btn)
            fig._home_btn_ref = home_btn
            _tb_x += 0.070

        # The ≡ Menu button.
        menu_ax = fig.add_axes([_tb_x, 0.955, 0.085, 0.038])
        menu_btn = Button(menu_ax, "≡  Menu  ▾",
                          color="#f1f5f9", hovercolor="#e2e8f0")
        _style_pill(menu_btn, menu_ax, "#f1f5f9", "#e2e8f0",
                    "#0f172a", "#94a3b8")
        menu_btn.on_clicked(lambda _e: _set_menu(not _controls["menu_open"]))
        fig._menu_btn_ref = menu_btn
        _tb_x += 0.090

        # ============================================================
        # View-preset dropdown — named standard camera angles, the way
        # SLB Petrel / Landmark COMPASS expose Top / Section / 3D views.
        # Sits beside the ≡ Menu button; opening one closes the other.
        # ============================================================
        _view = {"open": False, "items": []}

        def _set_view(elev, azim):
            _controls["view"] = (float(elev), float(azim))
            ax3d.view_init(elev=elev, azim=azim)
            fig.canvas.draw_idle()

        def _set_view_open(open_):
            _view["open"] = open_
            for vax, _vb in _view["items"]:
                vax.set_visible(open_)
            view_btn.label.set_text("View  ▴" if open_ else "View  ▾")
            if open_:
                _set_menu(False)  # mutually exclusive with the ≡ Menu
            fig.canvas.draw_idle()

        view_ax = fig.add_axes([_tb_x, 0.955, 0.080, 0.038])
        view_btn = Button(view_ax, "View  ▾",
                          color="#eef2ff", hovercolor="#e0e7ff")
        _style_pill(view_btn, view_ax, "#eef2ff", "#e0e7ff",
                    "#3730a3", "#4338ca")
        view_btn.on_clicked(lambda _e: _set_view_open(not _view["open"]))
        fig._view_btn_ref = view_btn

        # Compact 2-column grid of preset "blocks" — short labels so each
        # fits its button. Chosen for x=East, y=North, z=TVD (inverted).
        _VIEW_PRESETS = [
            ("3D",    20, -60),   # default oblique
            ("Top",   90, -90),   # plan / bird's-eye
            ("North",  0, -90),   # looking N: E-W spread vs TVD
            ("East",   0,   0),   # looking E: N-S spread vs TVD
            ("South",  0,  90),
            ("West",   0, 180),
        ]
        _vcol_w, _vrow_h = 0.072, 0.040
        _vgap_x, _vgap_y = 0.005, 0.006
        _vx0, _vy0 = _tb_x, 0.908
        for _i, (_lbl, _ev, _az) in enumerate(_VIEW_PRESETS):
            _r, _c = divmod(_i, 2)
            _vx = _vx0 + _c * (_vcol_w + _vgap_x)
            _vy = _vy0 - _r * (_vrow_h + _vgap_y)
            vax = fig.add_axes([_vx, _vy, _vcol_w, _vrow_h])
            vb = Button(vax, _lbl, color="#eef2ff", hovercolor="#e0e7ff")
            _style_pill(vb, vax, "#eef2ff", "#e0e7ff", "#3730a3", "#4338ca")
            vb.on_clicked(lambda _e, ev=_ev, az=_az: _set_view(ev, az))
            vax.set_visible(False)
            _view["items"].append((vax, vb))
        fig._view_item_refs = [b for _, b in _view["items"]]

        # Clicking ≡ Menu should also close the View dropdown.
        def _close_view_on_menu(_e):
            if _view["open"]:
                _set_view_open(False)
        menu_btn.on_clicked(_close_view_on_menu)

        # ---- Menu items (stacked below, hidden until ≡ is clicked) ---
        item_y = 0.910
        item_h = 0.038
        item_gap = 0.005
        item_x = 0.005
        item_w = 0.180

        def _add_menu_item(label, color, hover, text_color, border, on_click):
            nonlocal item_y
            ax = fig.add_axes([item_x, item_y, item_w, item_h])
            btn = Button(ax, label, color=color, hovercolor=hover)
            _style_pill(btn, ax, color, hover, text_color, border)
            btn.on_clicked(on_click)
            ax.set_visible(False)
            _controls["menu_items"].append((ax, btn))
            item_y -= (item_h + item_gap)
            return btn

        # (Home is now a dedicated always-visible button in the top-left
        # toolbar — see above — so it's no longer a menu item.)

        def _check(on, label):
            return ("✓  " if on else "     ") + label

        # DLS toggle (re-renders 3D)
        dls_btn = _add_menu_item(
            _check(color_by_dls, "DLS heatmap"),
            "#fef3c7", "#fde68a", "#92400e", "#b45309",
            lambda _e: _set_dls(not _controls["dls_on"]),
        )
        _controls["dls_btn"] = dls_btn

        # MD markers toggle (re-renders 3D)
        def _toggle_md(_e):
            _controls["md_on"] = not _controls["md_on"]
            _redraw_3d()
            _controls["md_btn"].label.set_text(
                _check(_controls["md_on"], "MD markers"))
            fig.canvas.draw_idle()

        md_btn = _add_menu_item(
            _check(show_md_markers, "MD markers"),
            "#e0f2fe", "#bae6fd", "#075985", "#0369a1",
            _toggle_md,
        )
        _controls["md_btn"] = md_btn

        # Plan view toggle (just hides the inset)
        def _toggle_plan(_e):
            if ax_plan is None: return
            _controls["plan_on"] = not _controls["plan_on"]
            ax_plan.set_visible(_controls["plan_on"])
            _controls["plan_btn"].label.set_text(
                _check(_controls["plan_on"], "Plan view"))
            fig.canvas.draw_idle()

        plan_btn = _add_menu_item(
            _check(show_plan_view, "Plan view"),
            "#ecfccb", "#d9f99d", "#3f6212", "#4d7c0f",
            _toggle_plan,
        )
        _controls["plan_btn"] = plan_btn

        # Section view toggle
        def _toggle_section(_e):
            if ax_sec is None: return
            _controls["section_on"] = not _controls["section_on"]
            ax_sec.set_visible(_controls["section_on"])
            _controls["section_btn"].label.set_text(
                _check(_controls["section_on"], "Section view"))
            fig.canvas.draw_idle()

        section_btn = _add_menu_item(
            _check(show_section_view, "Section view"),
            "#ecfccb", "#d9f99d", "#3f6212", "#4d7c0f",
            _toggle_section,
        )
        _controls["section_btn"] = section_btn

        # Deviation panel toggle
        if has_dev_panel and ax_dev is not None:
            def _toggle_dev(_e):
                _controls["dev_on"] = not _controls["dev_on"]
                ax_dev.set_visible(_controls["dev_on"])
                _controls["dev_btn"].label.set_text(
                    _check(_controls["dev_on"], "Deviation panel"))
                fig.canvas.draw_idle()

            dev_btn = _add_menu_item(
                _check(show_deviation_panel, "Deviation panel"),
                "#ecfccb", "#d9f99d", "#3f6212", "#4d7c0f",
                _toggle_dev,
            )
            _controls["dev_btn"] = dev_btn

            # Deviation-panel legend toggle (the congested one).
            def _toggle_dev_legend(_e):
                leg = getattr(ax_dev, "_dev_legend", None)
                if leg is None:
                    return
                _controls["devleg_on"] = not _controls["devleg_on"]
                leg.set_visible(_controls["devleg_on"])
                _controls["devleg_btn"].label.set_text(
                    _check(_controls["devleg_on"], "Deviation legend"))
                fig.canvas.draw_idle()

            devleg_btn = _add_menu_item(
                _check(True, "Deviation legend"),
                "#ecfccb", "#d9f99d", "#3f6212", "#4d7c0f",
                _toggle_dev_legend,
            )
            _controls["devleg_btn"] = devleg_btn

        # Legend toggle — fig.legend is the well-name strip at the top.
        def _toggle_legend(_e):
            _controls["legend_on"] = not _controls["legend_on"]
            for L in getattr(fig, "legends", []):
                L.set_visible(_controls["legend_on"])
            _controls["legend_btn"].label.set_text(
                _check(_controls["legend_on"], "Name legend"))
            fig.canvas.draw_idle()

        legend_btn = _add_menu_item(
            _check(True, "Name legend"),
            "#fce7f3", "#fbcfe8", "#831843", "#9d174d",
            _toggle_legend,
        )
        _controls["legend_btn"] = legend_btn

        # Maximise 3D — hides every inset panel + the DLS colourbar and
        # expands the 3D view to fill the canvas. Click again to restore
        # the multi-panel layout. Also maximises the OS window so we get
        # every pixel for the 3D plot.
        # Capture the 3D ax's original placement so we can restore it.
        _controls["ax3d_pos"] = ax3d.get_position().bounds

        def _toggle_fullscreen(_event):
            going_full = not _controls["fullscreen"]
            _controls["fullscreen"] = going_full
            # Maximise also flips into the immersive dark presentation theme.
            _controls["dark"] = going_full

            # Hide / show inset panels + deviation panel.
            for inset in (ax_plan, ax_sec, ax_dev):
                if inset is not None:
                    inset.set_visible(not going_full)

            # Resize the 3D axes — eat almost the whole canvas in maximised
            # mode (small margins for menu/title/footer only).
            if going_full:
                ax3d.set_position([0.03, 0.05, 0.94, 0.88])
            else:
                ax3d.set_position(_controls["ax3d_pos"])

            # Re-render the 3-D panel: "fill" box + dark theme in maximise,
            # "cubic" box + light theme in the default multi-panel view.
            # (_redraw_3d rebuilds the colourbar too, so no manual hide needed.)
            _redraw_3d()

            # Also maximise / restore the OS window for additional pixels.
            try:
                fig.canvas.manager.full_screen_toggle()
            except Exception:
                pass

            if _controls["fs_btn"] is not None:
                _controls["fs_btn"].label.set_text(
                    "✓  Maximise 3D" if going_full else "⛶  Maximise 3D"
                )
            fig.canvas.draw_idle()

        fs_btn = _add_menu_item(
            "⛶  Maximise 3D",
            "#ede9fe", "#ddd6fe", "#5b21b6", "#6d28d9",
            _toggle_fullscreen,
        )
        _controls["fs_btn"] = fs_btn

        # Save current view as PNG
        def _save_view(_event):
            try:
                from tkinter import filedialog
                path = filedialog.asksaveasfilename(
                    defaultextension=".png",
                    filetypes=[("PNG image", "*.png"), ("All files", "*.*")],
                    title="Save current view as…",
                )
                if path:
                    # Hide menu UI while saving so the chrome doesn't bake in.
                    _set_menu(False)
                    menu_ax.set_visible(False)
                    fig.canvas.draw()
                    fig.savefig(path, dpi=200, facecolor=fig.get_facecolor())
                    menu_ax.set_visible(True)
                    fig.canvas.draw_idle()
            except Exception as exc:
                print(f"Save failed: {exc}", file=sys.stderr)

        _add_menu_item(
            "💾  Save view as PNG…",
            "#dcfce7", "#bbf7d0", "#14532d", "#15803d",
            _save_view,
        )


    # Real scroll-wheel zoom that updates axis limits (not just projection),
    # plus a 'r' / double-click reset. Only attach when we're going to show
    # the window — pointless during --save runs.
    if not save_path:
        _attach_smart_zoom(fig, ax3d)
        _attach_fast_drag(fig, ax3d)

    if save_path:
        fig.savefig(save_path, dpi=200, facecolor=fig.get_facecolor())
        print(f"Saved plot to {save_path}")
        plt.close(fig)
        return False
    else:
        plt.show()
        return _controls.get("home_clicked", False)


def _attach_smart_zoom(fig, ax3d, base_scale: float = 1.25) -> None:
    """Wire scroll-wheel + 'r' + double-click to a proper 3-D zoom on `ax3d`.

    Default matplotlib 3-D scroll only rescales the projection — the tick
    labels and grid stay frozen at the original ranges, which feels broken
    when you zoom in. Here we recompute set_xlim3d / set_ylim3d / set_zlim3d
    so the axes redraw with new tick spacing each scroll step. Z-axis
    inversion (TVD increases downward) is preserved.

    Controls added:
        Mouse scroll  : zoom in (up) / out (down)  — updates axis labels
        'r' key       : reset view to original auto-scaled limits
        Double-click  : same as 'r'
    """
    # Capture initial limits so we can restore them on reset.
    fig.canvas.draw()  # ensure auto-limits have settled
    base_limits = {
        "x": ax3d.get_xlim3d(),
        "y": ax3d.get_ylim3d(),
        "z": ax3d.get_zlim3d(),
        "elev": ax3d.elev,
        "azim": ax3d.azim,
    }

    def _zoom(factor: float) -> None:
        for getter, setter in (
            (ax3d.get_xlim3d, ax3d.set_xlim3d),
            (ax3d.get_ylim3d, ax3d.set_ylim3d),
            (ax3d.get_zlim3d, ax3d.set_zlim3d),
        ):
            lo, hi = getter()
            mid = (lo + hi) / 2.0
            half = (hi - lo) / 2.0 * factor
            # Preserve axis direction (Z is inverted for TVD).
            if lo <= hi:
                setter(mid - half, mid + half)
            else:
                setter(mid + half, mid - half)
        fig.canvas.draw_idle()

    def _reset() -> None:
        ax3d.set_xlim3d(*base_limits["x"])
        ax3d.set_ylim3d(*base_limits["y"])
        ax3d.set_zlim3d(*base_limits["z"])
        ax3d.view_init(elev=base_limits["elev"], azim=base_limits["azim"])
        fig.canvas.draw_idle()

    def _on_scroll(event):
        if event.inaxes is not ax3d:
            return
        if event.button == "up":
            _zoom(1.0 / base_scale)
        elif event.button == "down":
            _zoom(base_scale)

    def _on_key(event):
        if event.key in ("r", "R"):
            _reset()

    def _on_dblclick(event):
        if event.inaxes is ax3d and event.dblclick:
            _reset()

    fig.canvas.mpl_connect("scroll_event", _on_scroll)
    fig.canvas.mpl_connect("key_press_event", _on_key)
    fig.canvas.mpl_connect("button_press_event", _on_dblclick)


def _attach_fast_drag(fig, ax3d) -> None:
    """Swap tube polygons for thin lines while the user is dragging.

    Matplotlib's 3-D rotation re-projects every Poly3DCollection face on
    every mouse-move event, which makes a multi-bore tube scene crawl at
    a few frames per second. Hiding the heavy mesh and showing a single
    coloured polyline per bore during drag turns rotation into something
    that feels native. As soon as the user releases the mouse, we restore
    the shaded tube.
    """
    state = {"dragging": False}

    def _set_fast(on: bool):
        pairs = getattr(ax3d, "_tube_pairs", None)
        if not pairs:
            return
        for poly, line in pairs:
            poly.set_visible(not on)
            line.set_visible(on)
        fig.canvas.draw_idle()

    def _on_press(event):
        if event.inaxes is ax3d and event.button == 1:  # left-button only
            state["dragging"] = True
            _set_fast(True)

    def _on_release(event):
        if state["dragging"]:
            state["dragging"] = False
            _set_fast(False)

    fig.canvas.mpl_connect("button_press_event", _on_press)
    fig.canvas.mpl_connect("button_release_event", _on_release)


# ---------------------------------------------------------------------------
# plot_wells helpers — each panel is its own drawer for clarity & testability
# ---------------------------------------------------------------------------

def _prepare_bores(bores, densify_step):
    """Run minimum-curvature + densification on every bore; collect drawing data.

    Returns (prepared_list, summaries_list, stations_per_bore_list).
    Each item in `prepared_list` is a dict with:
        name, color, role, is_planned,
        coarse (per-station list with file values honoured),
        fine   (densified per-station list for smooth line rendering),
        e, n, t, dls   (numpy arrays from `fine` for plotting),
        summary
    """
    prepared = []
    summaries = []
    stations_per_bore = []
    for i, bore in enumerate(bores):
        raw = bore.get("stations") or []
        if len(raw) < 2:
            continue
        sx = float(bore.get("surfaceX", 0.0))
        sy = float(bore.get("surfaceY", 0.0))
        sz = float(bore.get("surfaceZ", 0.0))

        coarse = minimum_curvature(raw, surface_x=sx, surface_y=sy, surface_z=sz)
        summary = compute_summary(coarse)
        bname = bore.get("name", f"Bore {i + 1}")
        summaries.append((bname, summary))
        stations_per_bore.append((bname, coarse))

        def _keep_file_fields(s):
            base = {"md": s["md"], "inc": s["inc"], "azi": s["azi"]}
            src = s.get("_source", {})
            for k in ("tvd", "north", "east", "dls"):
                if src.get(k) == "file":
                    base[k] = s[k]
            return base

        fine_raw = [_keep_file_fields(s) for s in coarse]
        densified_input = _densify_raw(fine_raw, step_md=densify_step)
        fine = minimum_curvature(densified_input, surface_x=sx, surface_y=sy, surface_z=sz)

        color = bore.get("color") or DEFAULT_COLORS[i % len(DEFAULT_COLORS)]
        role = (bore.get("role") or "actual").lower()
        prepared.append({
            "name": bname,
            "color": color,
            "role": role,
            "is_planned": role == "planned",
            "coarse": coarse,
            "fine": fine,
            "e": np.array([s["east"]  for s in fine]),
            "n": np.array([s["north"] for s in fine]),
            "t": np.array([s["tvd"]   for s in fine]),
            "md": np.array([s["md"]   for s in fine]),
            "dls": np.array([s["dls"] for s in fine]),
            "summary": summary,
        })
    return prepared, summaries, stations_per_bore


def _find_plan_actual_pairs(prepared):
    """Match planned and actual bores by display name. Returns list of pairs."""
    plans = {b["name"]: b for b in prepared if b["is_planned"]}
    actuals = {b["name"]: b for b in prepared if b["role"] == "actual"}
    return [{"plan": plans[n], "actual": actuals[n]}
            for n in plans if n in actuals]


def _compute_deviation(plan, actual):
    """For each actual station, find the interpolated plan position at the
    same MD and compute deltas.

    Returns a dict with parallel arrays:
        md             — MD of each actual station that fell inside plan's range
        d_north, d_east, d_tvd — signed deltas (actual − plan)
        d_horizontal   — horizontal Euclidean offset
        d_total        — full 3-D Euclidean distance
        max_total      — maximum 3-D distance + MD at which it occurs
        rms_total      — root-mean-square 3-D distance
    """
    p_md = plan["md"]
    p_n  = plan["n"]
    p_e  = plan["e"]
    p_t  = plan["t"]

    md_out, dn, de, dt = [], [], [], []
    for s_md, s_n, s_e, s_t in zip(actual["md"], actual["n"], actual["e"], actual["t"]):
        if s_md < p_md[0] or s_md > p_md[-1]:
            continue
        # np.interp does linear interpolation
        pn = float(np.interp(s_md, p_md, p_n))
        pe = float(np.interp(s_md, p_md, p_e))
        pt = float(np.interp(s_md, p_md, p_t))
        md_out.append(s_md)
        dn.append(s_n - pn)
        de.append(s_e - pe)
        dt.append(s_t - pt)

    if not md_out:
        return {
            "md": np.array([]), "d_north": np.array([]), "d_east": np.array([]),
            "d_tvd": np.array([]), "d_horizontal": np.array([]), "d_total": np.array([]),
            "max_total": 0.0, "max_md": 0.0, "rms_total": 0.0,
        }
    md_a = np.array(md_out); dn = np.array(dn); de = np.array(de); dt = np.array(dt)
    dh = np.sqrt(dn**2 + de**2)
    dtot = np.sqrt(dh**2 + dt**2)
    i_max = int(np.argmax(dtot))
    return {
        "md": md_a, "d_north": dn, "d_east": de, "d_tvd": dt,
        "d_horizontal": dh, "d_total": dtot,
        "max_total": float(dtot[i_max]), "max_md": float(md_a[i_max]),
        "rms_total": float(np.sqrt(np.mean(dtot**2))),
    }


def _build_layout(fig, *, show_insets, show_plan, show_section, show_dev):
    """Wire up the figure's gridspec based on which panels are enabled.

    Returns (ax3d, ax_plan, ax_section, ax_dev). Any axis can be None.
    """
    from matplotlib.gridspec import GridSpec

    if show_insets and show_dev:
        # 3D | plan
        # 3D | section
        # dev|  dev
        gs = GridSpec(3, 2, figure=fig, width_ratios=[3.4, 1],
                      height_ratios=[3, 3, 2], hspace=0.45, wspace=0.30,
                      left=0.04, right=0.95, top=0.94, bottom=0.13)
        ax3d  = fig.add_subplot(gs[0:2, 0], projection="3d")
        ax_p  = fig.add_subplot(gs[0, 1]) if show_plan else None
        ax_s  = fig.add_subplot(gs[1, 1]) if show_section else None
        ax_d  = fig.add_subplot(gs[2, :])
    elif show_insets:
        gs = GridSpec(2, 2, figure=fig, width_ratios=[3.4, 1],
                      height_ratios=[1, 1], hspace=0.40, wspace=0.30,
                      left=0.04, right=0.95, top=0.94, bottom=0.13)
        ax3d  = fig.add_subplot(gs[:, 0], projection="3d")
        ax_p  = fig.add_subplot(gs[0, 1]) if show_plan else None
        ax_s  = fig.add_subplot(gs[1, 1]) if show_section else None
        ax_d  = None
    elif show_dev:
        gs = GridSpec(2, 1, figure=fig, height_ratios=[3, 1], hspace=0.28)
        ax3d  = fig.add_subplot(gs[0], projection="3d")
        ax_p  = None
        ax_s  = None
        ax_d  = fig.add_subplot(gs[1])
    else:
        ax3d = fig.add_subplot(111, projection="3d")
        ax_p = ax_s = ax_d = None

    # Theme any 2-D inset/deviation axes.
    for ax in (ax_p, ax_s, ax_d):
        if ax is None:
            continue
        ax.set_facecolor(_BG)
        ax.tick_params(colors=_FG_DIM, labelsize=8)
        for spine in ax.spines.values():
            spine.set_color(_GRID)
        ax.grid(True, color=_GRID, alpha=0.6, linewidth=0.6)

    return ax3d, ax_p, ax_s, ax_d


def _draw_3d(ax, prepared, *, color_by_dls, dls_cmap, dls_norm,
             show_md_markers, box_mode: str = "cubic", dark: bool = False):
    """Render the main 3-D view.

    `dark=True` switches to an immersive dark "casing-wear" presentation
    theme (used by Maximise 3D) — dark panes, light grid + labels — closer
    to how commercial drilling viewers (SLB / Landmark) present a single
    wellbore in detail.
    """
    fig = ax.get_figure()

    # ---- theme palette --------------------------------------------------
    if dark:
        c_bg, c_pane, c_grid = "#0b1220", "#16243d", "#3b4d6b"
        c_fg, c_fg_dim       = "#e8eef6", "#9fb3cc"
        c_legend_bg, c_legend_ed = "#1e293b", "#475569"
        c_md_dot, c_md_label = "#cbd5e1", "#e2e8f0"
    else:
        c_bg, c_pane, c_grid = _BG, _PANE, _GRID
        c_fg, c_fg_dim       = _FG, _FG_DIM
        c_legend_bg, c_legend_ed = _LEGEND_BG, _LEGEND_EDGE
        c_md_dot, c_md_label = _MD_DOT, _MD_LABEL

    # Whole-figure background follows the theme so maximise reads as one
    # immersive dark scene; restored to white when un-maximised.
    fig.patch.set_facecolor(c_bg)
    ax.set_facecolor(c_bg)
    pane_rgba = (*[int(c_pane[i:i + 2], 16) / 255 for i in (1, 3, 5)], 1.0)
    for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
        axis.set_pane_color(pane_rgba)
        axis.label.set_color(c_fg)
        axis._axinfo["grid"]["color"] = (
            int(c_grid[1:3], 16) / 255,
            int(c_grid[3:5], 16) / 255,
            int(c_grid[5:7], 16) / 255,
            0.85,
        )
    ax.tick_params(colors=c_fg_dim)

    all_e, all_n, all_t = [], [], []
    legend_handles = []
    any_planned = any(b["is_planned"] for b in prepared)

    # Collect (poly, fast_line) tube pairs for the drag-swap interaction.
    tube_pairs = []

    # ---- auto-scale a visual tube radius from the overall data extent -------
    for b in prepared:
        all_e.extend(b["e"].tolist()); all_n.extend(b["n"].tolist()); all_t.extend(b["t"].tolist())
    if all_e:
        span_e = max(all_e) - min(all_e)
        span_n = max(all_n) - min(all_n)
        span_t = max(all_t) - min(all_t)
        diag = math.sqrt(span_e ** 2 + span_n ** 2 + span_t ** 2)
        tube_radius = max(diag * 0.006, 1.0)
    else:
        tube_radius = 1.0

    for b in prepared:
        e, n, t = b["e"], b["n"], b["t"]

        if color_by_dls and dls_cmap is not None and dls_norm is not None:
            if b["is_planned"]:
                # Plan stays a ghost line so the DLS-coloured actual reads clearly.
                ax.plot(e, n, t, color="#94a3b8", linewidth=1.8,
                        linestyle="--", alpha=0.5, zorder=4)
            else:
                poly, fast_line = _draw_tube(
                    ax, e, n, t, base_color=b["color"], radius=tube_radius,
                    scalar=b["dls"], cmap=dls_cmap, norm=dls_norm, zorder=5)
                if poly is not None:
                    tube_pairs.append((poly, fast_line))
            legend_color = c_fg  # neutral marker in legend when DLS-coloured
        else:
            color = b["color"]
            if b["is_planned"]:
                ax.plot(e, n, t, color=color, linewidth=2.0,
                        linestyle="--", alpha=0.5, zorder=4)
            else:
                poly, fast_line = _draw_tube(
                    ax, e, n, t, base_color=color, radius=tube_radius, zorder=5)
                if poly is not None:
                    tube_pairs.append((poly, fast_line))
            legend_color = color

        # Wellhead + toe markers.
        if not b["is_planned"]:
            ax.scatter([e[0]], [n[0]], [t[0]],
                       color=_WELLHEAD, edgecolors="black", linewidths=1.2,
                       s=150, depthshade=False, zorder=10)
            ax.scatter([e[-1]], [n[-1]], [t[-1]],
                       color=b["color"], edgecolors="black", linewidths=1.0,
                       s=90, depthshade=False, zorder=10, marker="v")
        else:
            ax.scatter([e[-1]], [n[-1]], [t[-1]],
                       facecolors="none", edgecolors=b["color"], linewidths=1.4,
                       s=80, depthshade=False, zorder=8, marker="v", alpha=0.6)

        if show_md_markers and not b["is_planned"]:
            _draw_md_markers(ax, b["coarse"],
                             dot_color=c_md_dot, label_color=c_md_label)

        # Legend
        if any_planned:
            tag = "planned" if b["is_planned"] else "actual"
            label = f"{b['name']} ({tag})"
        else:
            label = f"{b['name']} ({b['summary']['classification']})"
        legend_handles.append(
            Line2D([0], [0], color=legend_color,
                   lw=2.0 if b["is_planned"] else 2.6,
                   linestyle="--" if b["is_planned"] else "-",
                   alpha=0.45 if b["is_planned"] else 1.0,
                   label=label)
        )

    # Legend lives on the FIGURE, not inside the 3-D axes, so it never
    # overlaps the wellbore no matter how the user rotates the camera.
    # Remove any previous figure legend (re-rendered on each toggle).
    for prev in list(getattr(fig, "legends", [])):
        prev.remove()
    if legend_handles and (any_planned or len(legend_handles) > 1):
        ncol = min(len(legend_handles), 4)
        leg = fig.legend(handles=legend_handles,
                         loc="upper center",
                         bbox_to_anchor=(0.5, 0.965),
                         ncol=ncol, framealpha=0.92,
                         fontsize=8, borderpad=0.5,
                         handlelength=1.6, labelspacing=0.3,
                         columnspacing=1.4)
        leg.get_frame().set_facecolor(c_legend_bg)
        leg.get_frame().set_edgecolor(c_legend_ed)
        leg.get_frame().set_linewidth(0.5)
        for text in leg.get_texts():
            text.set_color(c_fg)
    elif not legend_handles:
        ax.text2D(0.5, 0.5, "No survey stations to plot.",
                  ha="center", va="center", transform=ax.transAxes, color=c_fg_dim)

    ax.set_xlabel("East",  color=c_fg, labelpad=12, fontsize=8.5)
    ax.set_ylabel("North", color=c_fg, labelpad=12, fontsize=8.5)
    ax.set_zlabel("TVD",   color=c_fg, labelpad=10, fontsize=8.5)
    ax.tick_params(axis="both", which="major", labelsize=7, pad=1)
    # Cap tick count so numbers don't pile up / overlap where axes meet at
    # the box corners (4 bins on the horizontal axes is plenty and keeps the
    # East/North tick labels from colliding at oblique angles).
    from matplotlib.ticker import MaxNLocator
    ax.xaxis.set_major_locator(MaxNLocator(nbins=4, prune="both"))
    ax.yaxis.set_major_locator(MaxNLocator(nbins=4, prune="both"))
    ax.zaxis.set_major_locator(MaxNLocator(nbins=6))
    ax.invert_zaxis()
    _equal_3d_box(ax, all_e, all_n, all_t, mode=box_mode)
    ax.view_init(elev=20, azim=-60)

    # Stash the tube pairs on the axis so the figure-level drag handler
    # in plot_wells can swap them for fast lines during rotation.
    ax._tube_pairs = tube_pairs


# ---------------------------------------------------------------------------
# Tube rendering — sweep a circular cross-section along the trajectory and
# Lambert-shade the faces so the wellbore reads as a solid 3-D pipe rather
# than a flat line. This is the main "graphics quality" upgrade.
# ---------------------------------------------------------------------------

# Fixed light direction in data space (upper-left-front). Z is TVD with the
# axis inverted, so -Z points "up" on screen. Tuned to give a soft rounded look.
_LIGHT_DIR = np.array([-0.35, -0.45, -0.82])
_LIGHT_DIR = _LIGHT_DIR / np.linalg.norm(_LIGHT_DIR)


def _resample_polyline(P, scalar=None, max_points=120):
    """Down-sample a polyline to at most `max_points` evenly-indexed points.

    Keeps the first and last point. Returns (P_out, scalar_out). Keeping the
    face count bounded keeps rotation smooth even for dense surveys.
    """
    n = len(P)
    if n <= max_points:
        return P, scalar
    idx = np.linspace(0, n - 1, max_points).round().astype(int)
    idx = np.unique(idx)
    out_s = scalar[idx] if scalar is not None else None
    return P[idx], out_s


def _tube_frames(P):
    """Rotation-minimising frame (parallel transport) along polyline P (N,3).

    Returns tangents T, normals Nv, binormals B — each (N,3) and orthonormal.
    Parallel transport avoids the abrupt twist a naive Frenet frame produces at
    near-straight or inflecting sections.
    """
    n = len(P)
    T = np.zeros((n, 3))
    T[1:-1] = P[2:] - P[:-2]
    T[0] = P[1] - P[0]
    T[-1] = P[-1] - P[-2]
    norms = np.linalg.norm(T, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    T = T / norms

    Nv = np.zeros((n, 3))
    B = np.zeros((n, 3))
    arbitrary = np.array([0.0, 0.0, 1.0])
    if abs(float(np.dot(T[0], arbitrary))) > 0.9:
        arbitrary = np.array([1.0, 0.0, 0.0])
    n0 = arbitrary - np.dot(arbitrary, T[0]) * T[0]
    n0 /= (np.linalg.norm(n0) or 1.0)
    Nv[0] = n0
    B[0] = np.cross(T[0], Nv[0])
    for i in range(1, n):
        v = Nv[i - 1] - np.dot(Nv[i - 1], T[i]) * T[i]
        ln = np.linalg.norm(v)
        Nv[i] = v / ln if ln > 1e-9 else Nv[i - 1]
        B[i] = np.cross(T[i], Nv[i])
    return T, Nv, B


def _shade_rgb(base_rgb, brightness):
    """Multiply an RGB triple by a (M,) brightness array → (M,3) clipped RGB."""
    base = np.asarray(base_rgb).reshape(1, 3)
    out = base * brightness.reshape(-1, 1)
    return np.clip(out, 0.0, 1.0)


def _draw_tube(ax, e, n, t, *, base_color, radius, sides=10, alpha=1.0,
               scalar=None, cmap=None, norm=None, zorder=5):
    """Sweep a circular cross-section along (e,n,t) and add it as a shaded mesh.

    Returns (poly, fast_line) where `fast_line` is a thin centreline polyline
    drawn but hidden by default. The interaction handler in plot_wells swaps
    visibility on drag — hiding the heavy polygon mesh and showing the cheap
    line — so rotation stays smooth on big multi-bore datasets.
    """
    from matplotlib.colors import to_rgb
    from mpl_toolkits.mplot3d.art3d import Poly3DCollection

    P = np.stack([e, n, t], axis=1).astype(float)
    if len(P) < 2:
        return None, None
    P, scalar = _resample_polyline(P, scalar)

    T, Nv, B = _tube_frames(P)
    theta = np.linspace(0.0, 2.0 * np.pi, sides, endpoint=False)
    cos_t = np.cos(theta)[None, :, None]
    sin_t = np.sin(theta)[None, :, None]
    # rings: (N, sides, 3)
    rings = (P[:, None, :]
             + radius * (cos_t * Nv[:, None, :] + sin_t * B[:, None, :]))

    r0 = rings[:-1]                       # (N-1, sides, 3)
    r1 = rings[1:]
    j = np.arange(sides)
    j2 = (j + 1) % sides
    a = r0[:, j, :]
    b = r0[:, j2, :]
    c = r1[:, j2, :]
    d = r1[:, j, :]
    faces = np.stack([a, b, c, d], axis=2).reshape(-1, 4, 3)  # (M,4,3)

    # Face normals (outward) and Lambert + back-light brightness.
    e1 = (b - a).reshape(-1, 3)
    e2 = (d - a).reshape(-1, 3)
    fn = np.cross(e1, e2)
    fl = np.linalg.norm(fn, axis=1, keepdims=True)
    fl[fl == 0] = 1.0
    fn = fn / fl
    dot = fn @ _LIGHT_DIR
    brightness = 0.55 + 0.50 * np.clip(dot, 0, 1) + 0.12 * np.clip(-dot, 0, 1)

    if scalar is not None and cmap is not None and norm is not None:
        seg_scalar = (scalar[:-1] + scalar[1:]) / 2.0           # (N-1,)
        face_scalar = np.repeat(seg_scalar, sides)              # (M,)
        rgb = cmap(norm(face_scalar))[:, :3]
        rgb = np.clip(rgb * brightness.reshape(-1, 1), 0, 1)
    else:
        rgb = _shade_rgb(to_rgb(base_color), brightness)

    facecolors = np.concatenate([rgb, np.full((len(rgb), 1), alpha)], axis=1)

    poly = Poly3DCollection(faces, facecolors=facecolors,
                            edgecolors=facecolors, linewidths=0.2,
                            antialiased=True, zorder=zorder)
    poly.set_sort_zpos(None)
    ax.add_collection3d(poly)

    # Crisp specular-ish highlight: a thin lightened centreline on top.
    hl = np.clip(np.asarray(to_rgb(base_color)) * 1.35 + 0.12, 0, 1)
    ax.plot(P[:, 0], P[:, 1], P[:, 2], color=hl, linewidth=0.9,
            alpha=0.55 * alpha, zorder=zorder + 1)

    # Fast-draw fallback: a thick coloured line we can swap in during drag
    # so the user gets immediate visual feedback instead of waiting on the
    # polygon mesh to rebuild. Hidden until the interaction handler shows it.
    fast_line, = ax.plot(P[:, 0], P[:, 1], P[:, 2],
                         color=to_rgb(base_color), linewidth=2.4,
                         alpha=alpha, zorder=zorder, visible=False,
                         solid_capstyle="round")
    return poly, fast_line


def _draw_dls_colored_line(ax, e, n, t, dls, cmap, norm, is_planned):
    """Draw a 3-D polyline with per-segment colour driven by DLS.

    Uses Line3DCollection so each segment between consecutive densified
    stations can take its own colour from the DLS colormap. Plan-vs-actual
    distinction is kept via dashed line style.
    """
    from mpl_toolkits.mplot3d.art3d import Line3DCollection

    # Build (N-1) segments of shape (2, 3): start point and end point per segment.
    pts = np.stack([e, n, t], axis=1).reshape(-1, 1, 3)
    segs = np.concatenate([pts[:-1], pts[1:]], axis=1)
    seg_dls = (dls[:-1] + dls[1:]) / 2.0  # average per segment

    lc = Line3DCollection(
        segs, cmap=cmap, norm=norm,
        linestyles="--" if is_planned else "-",
        linewidths=2.0 if is_planned else 2.6,
        alpha=0.6 if is_planned else 1.0,
        zorder=4 if is_planned else 5,
    )
    lc.set_array(seg_dls)
    ax.add_collection3d(lc)


def _draw_plan_view(ax, prepared):
    """Top-down view: East (X) vs North (Y). Looking straight down the Z axis."""
    ax.set_title("Plan view", color=_FG, fontsize=9, pad=4)
    ax.set_xlabel("E",  color=_FG_DIM, fontsize=8, labelpad=2)
    ax.set_ylabel("N",  color=_FG_DIM, fontsize=8, labelpad=2)
    ax.set_aspect("equal", adjustable="datalim")
    ax.tick_params(labelsize=7)

    for b in prepared:
        if b["is_planned"]:
            ax.plot(b["e"], b["n"], color=b["color"], linewidth=1.3,
                    linestyle="--", alpha=0.55)
        else:
            ax.plot(b["e"], b["n"], color=b["color"], linewidth=1.6)
        # Compact wellhead + toe markers (panels are small).
        ax.scatter([b["e"][0]], [b["n"][0]],
                   color=_WELLHEAD, edgecolors="black", linewidths=0.6,
                   s=22, zorder=5)
        ax.scatter([b["e"][-1]], [b["n"][-1]],
                   color="none" if b["is_planned"] else b["color"],
                   edgecolors=b["color"], linewidths=1.0, s=20,
                   marker="v", zorder=5)

    # SLB-style compass rose in the corner — North points up in plan view.
    ax.annotate("N",
                xy=(0.93, 0.95), xytext=(0.93, 0.80),
                xycoords="axes fraction", textcoords="axes fraction",
                ha="center", va="center", fontsize=8, fontweight="bold",
                color=_FG_DIM,
                arrowprops=dict(arrowstyle="-|>", color=_FG_DIM, lw=1.1))


def _draw_section_view(ax, prepared):
    """Section view: horizontal displacement (X) vs TVD (Y, inverted).

    For multi-bore wells we use sqrt(N² + E²) as the horizontal axis — a
    'horizontal departure' that is independent of azimuth direction. This is
    simpler and clearer than the classical Vs (projection onto a chosen
    section azimuth) when bores in the same plot point different directions.
    """
    ax.set_title("Section", color=_FG, fontsize=9, pad=4)
    ax.set_xlabel("Horiz", color=_FG_DIM, fontsize=8, labelpad=2)
    ax.set_ylabel("TVD",   color=_FG_DIM, fontsize=8, labelpad=2)
    ax.tick_params(labelsize=7)
    ax.invert_yaxis()  # depth grows downward

    for b in prepared:
        horiz = np.sqrt(b["n"]**2 + b["e"]**2)
        if b["is_planned"]:
            ax.plot(horiz, b["t"], color=b["color"], linewidth=1.3,
                    linestyle="--", alpha=0.55)
        else:
            ax.plot(horiz, b["t"], color=b["color"], linewidth=1.6)
        ax.scatter([horiz[0]], [b["t"][0]],
                   color=_WELLHEAD, edgecolors="black", linewidths=0.6,
                   s=22, zorder=5)
        ax.scatter([horiz[-1]], [b["t"][-1]],
                   color="none" if b["is_planned"] else b["color"],
                   edgecolors=b["color"], linewidths=1.0, s=20,
                   marker="v", zorder=5)


def _draw_deviation_panel(ax, deviations, prepared):
    """Plot actual-vs-plan deviation curves (one per pair) along MD.

    Three lines per pair: total Euclidean offset, horizontal offset, vertical
    offset (signed). Each pair's colour matches the bore-pair colour.

    Stores the legend on `ax._dev_legend` so the ≡ Menu can toggle it; the
    title is left-aligned and the legend tucked top-right so they don't
    fight for the same corner.
    """
    color_for = {b["name"]: b["color"] for b in prepared}
    drawn = [(n, d) for n, d in deviations if len(d["md"])]
    single = len(drawn) <= 1   # drop the redundant bore name when only one pair

    # Fold the max figure into the title for a single pair — keeps it on
    # screen (the old data-point annotation ran off the right edge at high MD).
    if single and drawn:
        _, d0 = drawn[0]
        ttl = (f"Plan vs Actual deviation   ·   "
               f"max {d0['max_total']:.0f} @ MD {d0['max_md']:.0f}")
    else:
        ttl = "Plan vs Actual deviation along MD"
    ax.set_title(ttl, color=_FG, fontsize=9.5, pad=6, loc="left")
    ax.set_xlabel("MD",        color=_FG_DIM, fontsize=9)
    ax.set_ylabel("Deviation", color=_FG_DIM, fontsize=9)
    ax.axhline(0, color=_GRID, linewidth=0.7)

    handles = []
    for name, dev in drawn:
        col = color_for.get(name, "#0284c7")
        pfx = "" if single else f"{name[:12]}: "
        ax.plot(dev["md"], dev["d_total"], color=col, linewidth=1.8,
                label=f"{pfx}Total")
        ax.plot(dev["md"], dev["d_horizontal"], color=col, linewidth=1.0,
                linestyle="--", alpha=0.7, label=f"{pfx}Horiz")
        ax.plot(dev["md"], dev["d_tvd"], color=col, linewidth=1.0,
                linestyle=":", alpha=0.7, label=f"{pfx}Vert")
        # For multi-pair, mark the peak with an adaptive-side label that
        # never spills off the right edge. Single-pair max is in the title.
        if not single:
            mid = (dev["md"][0] + dev["md"][-1]) / 2.0
            right = dev["max_md"] > mid
            ax.annotate(
                f"{name[:12]} max {dev['max_total']:.0f}",
                xy=(dev["max_md"], dev["max_total"]),
                xytext=(-8 if right else 8, 6), textcoords="offset points",
                ha="right" if right else "left",
                color=col, fontsize=7.5,
                arrowprops=dict(arrowstyle="-", color=col, lw=0.6),
            )
        handles.append(name)

    if handles:
        # Legend in the top-LEFT — early-MD deviation is ~0 so this corner is
        # empty, and it stays clear of the rising curve on the right.
        leg = ax.legend(loc="upper left", framealpha=0.9, fontsize=7.5,
                        ncol=3, columnspacing=1.1, handlelength=1.5,
                        borderpad=0.4, labelspacing=0.3)
        leg.get_frame().set_facecolor(_LEGEND_BG)
        leg.get_frame().set_edgecolor(_LEGEND_EDGE)
        leg.get_frame().set_linewidth(0.5)
        for text in leg.get_texts():
            text.set_color(_FG)
        ax._dev_legend = leg


def _densify_raw(raw_stations: List[dict], step_md: float) -> List[dict]:
    """Insert MD-spaced interpolated stations between raw (md/inc/azi) tuples."""
    if len(raw_stations) < 2 or step_md <= 0:
        return raw_stations
    dense: List[dict] = []
    for a, b in zip(raw_stations[:-1], raw_stations[1:]):
        dense.append(a)
        gap = b["md"] - a["md"]
        if gap <= step_md:
            continue
        n = int(gap // step_md)
        for k in range(1, n + 1):
            t = (k * step_md) / gap
            if t >= 1.0:
                break
            dense.append({
                "md":  a["md"]  + t * gap,
                "inc": a["inc"] + t * (b["inc"] - a["inc"]),
                "azi": _interp_azi(a["azi"], b["azi"], t),
            })
    dense.append(raw_stations[-1])
    return dense


def _draw_md_markers(ax, stations: List[dict],
                     dot_color=_MD_DOT, label_color=_MD_LABEL) -> None:
    """Drop labelled scatter points along the wellpath at evenly-spaced MD intervals.

    Marker count scales with well length and is kept conservative so labels
    don't crowd the 3-D view. Colours default to the light theme but can be
    overridden (e.g. for the dark Maximise-3D presentation theme).
    """
    if len(stations) < 2:
        return
    total_md = stations[-1]["md"] - stations[0]["md"]
    # Fewer markers, more breathing room. Roughly one per ~700 MD units.
    target = min(8, max(3, int(round(total_md / 700))))
    if target <= 1:
        return
    step = total_md / target

    for i in range(1, target):
        md_target = stations[0]["md"] + step * i
        s = next((s for s in stations if s["md"] >= md_target), None)
        if s is None:
            continue
        ax.scatter([s["east"]], [s["north"]], [s["tvd"]],
                   color=dot_color, s=12, depthshade=False, zorder=7, alpha=0.7)
        ax.text(s["east"], s["north"], s["tvd"], f"  {int(md_target)}",
                fontsize=6.5, color=label_color, zorder=9, alpha=0.8)


def _default_title(summaries: List[Tuple[str, dict]]) -> str:
    if not summaries:
        return "Well-Viz 3D"
    if len(summaries) == 1:
        name, s = summaries[0]
        return (f"{name} — {s['classification']}   "
                f"MD {s['totalMd']:,.0f}  ·  TVD {s['totalTvd']:,.0f}  ·  "
                f"reach {s['horizontalReach']:,.0f}")
    return f"Multi-bore well · {len(summaries)} legs"


def _print_text_summary(summaries: List[Tuple[str, dict]], stations_per_bore=None,
                        deviations=None) -> None:
    if not summaries:
        return
    print()
    print("Wellbore summary")
    print("-" * 64)
    print(f"{'Bore':<22s} {'Class':<11s} {'MD':>10s} {'TVD':>10s} {'Reach':>10s} {'MaxInc':>7s}")
    for name, s in summaries:
        print(f"{name[:22]:<22s} {s['classification']:<11s} "
              f"{s['totalMd']:>10.1f} {s['totalTvd']:>10.1f} "
              f"{s['horizontalReach']:>10.1f} {s['maxInclination']:>7.1f}")

    # Plan-vs-actual deviation block.
    if deviations:
        print()
        print("Plan-vs-Actual deviation (actual - plan)")
        print("-" * 64)
        print(f"{'Pair':<22s} {'Max 3D':>10s} {'@MD':>10s} {'RMS':>10s} "
              f"{'MeanHoriz':>10s}")
        for name, dev in deviations:
            if len(dev["md"]) == 0:
                print(f"{name[:22]:<22s} {'(no overlapping MD range)':>52s}")
                continue
            mean_h = float(np.mean(dev["d_horizontal"]))
            print(f"{name[:22]:<22s} {dev['max_total']:>10.1f} "
                  f"{dev['max_md']:>10.1f} {dev['rms_total']:>10.2f} "
                  f"{mean_h:>10.1f}")

    # Surface origin of the position numbers we're displaying.
    if stations_per_bore:
        sources_used = _aggregate_sources(stations_per_bore)
        if any(sources_used.values()):
            print()
            print("Position fields honoured from file (rather than recomputed):")
            for bore_name, fields in sources_used.items():
                if fields:
                    print(f"  {bore_name}: {', '.join(sorted(fields))}")
    print()


def _aggregate_sources(stations_per_bore):
    """Return {bore_name: set_of_field_names_with_at_least_one_file_value}."""
    summary = {}
    for bore_name, stations in stations_per_bore:
        used = set()
        for s in stations:
            src = s.get("_source", {})
            for field, origin in src.items():
                if origin == "file":
                    used.add(field)
        summary[bore_name] = used
    return summary


# ===========================================================================
# 4. Upload GUI (tkinter)
# ===========================================================================
# A small modal window that lets the user pick survey files (planned /
# actual / standalone), labels them, and then hands off to plot_wells.
# tkinter is imported lazily so the rest of the script still works on
# Python builds without it (e.g. some Linux server installs).


# Heuristic: filename tokens that imply role.
_PLAN_TOKENS    = ("plan", "planned", "design", "target", "prog")  # 'prog'rammed
_ACTUAL_TOKENS  = ("actual", "actl", "asdrilled", "as-drilled", "drilled", "real", "survey")


def _guess_role_from_filename(path: str) -> str:
    """Sniff a filename for plan/actual tokens. Default 'actual'."""
    stem = Path(path).stem.lower()
    flat = re.sub(r"[\s_\-.]", "", stem)
    if any(tok in flat for tok in _PLAN_TOKENS):
        return "planned"
    return "actual"


def _quick_metadata(path: str) -> dict:
    """Open a file and return a small preview dict for the table row.

    Returns {'stations': int, 'md_range': str, 'classification': str, 'error': str|None}.
    Failures don't raise — they go into the 'error' field so the row can still
    display something sensible.
    """
    try:
        bores = load_survey(path)
        if not bores:
            return {"stations": 0, "md_range": "—", "classification": "—", "error": "no bores"}
        # For a multi-bore file (rare in the upload flow), aggregate.
        total = 0
        md_min = float("inf"); md_max = float("-inf")
        classes = []
        for bore in bores:
            raw = bore.get("stations") or []
            if not raw:
                continue
            traj = minimum_curvature(raw)
            total += len(traj)
            md_min = min(md_min, traj[0]["md"])
            md_max = max(md_max, traj[-1]["md"])
            classes.append(compute_summary(traj)["classification"])
        if total == 0:
            return {"stations": 0, "md_range": "—", "classification": "—", "error": "empty"}
        cls = classes[0] if len(set(classes)) == 1 else "/".join(sorted(set(classes)))
        return {
            "stations": total,
            "md_range": f"{md_min:.0f}–{md_max:.0f}",
            "classification": cls,
            "error": None,
        }
    except Exception as exc:
        return {"stations": 0, "md_range": "—", "classification": "—", "error": str(exc)[:40]}


def launch_gui():
    """Open the upload window in a loop: Upload → Plot → (Home? loop back) → exit.

    The loop pattern avoids the recursion bug that happens when the matplotlib
    Home button tries to re-enter launch_gui while plt.show() is still running.
    Now Home just closes the plot window cleanly; the loop iterates to re-open
    the upload screen.
    """
    while True:
        result = _show_upload_dialog()
        if result is None:
            return 0  # user cancelled the upload window
        wants_home = plot_wells(
            result["bores"],
            show_md_markers     = result["md"],
            show_plan_view      = result["plan"],
            show_section_view   = result["section"],
            show_deviation_panel= result["dev"],
            color_by_dls        = result["dls"],
            allow_home          = True,
        )
        if not wants_home:
            return 0  # plot window closed naturally — exit program


def _show_upload_dialog():
    """Show the upload window and block until the user clicks Plot or Cancel.

    Returns a dict of plot args, or None if the user cancelled.
    """
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox, ttk
    except ImportError as exc:
        print(f"GUI requires tkinter, which is not available: {exc}", file=sys.stderr)
        print("On Debian/Ubuntu:  sudo apt install python3-tk", file=sys.stderr)
        return None

    state = {"files": []}  # [{path, role, name, meta}]

    root = tk.Tk()
    root.title("Well-Viz 3D  —  Upload Surveys")

    # Pin tk's font scaling to the screen's actual DPI, AND scale the
    # window geometry the same way. Without this, a literal "820x680"
    # geometry on a HiDPI screen renders absurdly small (this caused the
    # "window shrinks on Home" regression after we set DPI awareness).
    try:
        dpi = float(root.winfo_fpixels("1i"))
        font_scale = dpi / 72.0     # tk's text scaling baseline
        size_scale = dpi / 96.0     # Windows pixel baseline
        root.tk.call("tk", "scaling", font_scale)
    except Exception:
        size_scale = 1.0

    nom_w, nom_h = 860, 820
    w = int(nom_w * size_scale)
    h = int(nom_h * size_scale)
    root.geometry(f"{w}x{h}")
    root.minsize(int(700 * size_scale), int(680 * size_scale))

    # Centre the window on whatever monitor it lands on.
    root.update_idletasks()
    try:
        sw = root.winfo_screenwidth()
        sh = root.winfo_screenheight()
        root.geometry(f"{w}x{h}+{(sw - w) // 2}+{(sh - h) // 2}")
    except Exception:
        pass

    root.configure(bg="#f8fafc")

    # ttk styling — picks up the native Windows look while letting us recolour.
    style = ttk.Style(root)
    try:
        style.theme_use("vista")  # Windows; safe fallback below
    except tk.TclError:
        for theme in ("clam", "default"):
            try: style.theme_use(theme); break
            except tk.TclError: pass

    # Modernised palette
    C_CANVAS    = "#f8fafc"   # outermost canvas
    C_CARD      = "#ffffff"   # card backgrounds
    C_CARD_BD   = "#e2e8f0"   # card borders
    C_FG        = "#0f172a"
    C_FG_DIM    = "#64748b"
    C_FG_MUTED  = "#94a3b8"
    C_ACCENT    = "#0284c7"

    style.configure("Treeview",
                    background=C_CARD, fieldbackground=C_CARD,
                    foreground=C_FG, rowheight=28, borderwidth=0,
                    font=("Segoe UI", 9))
    style.configure("Treeview.Heading",
                    background="#f1f5f9", foreground=C_FG_DIM,
                    relief="flat", font=("Segoe UI", 8, "bold"),
                    padding=(8, 6))
    style.map("Treeview",
              background=[("selected", "#dbeafe")],
              foreground=[("selected", C_FG)])
    style.layout("Treeview", [
        ("Treeview.treearea", {"sticky": "nswe"}),
    ])

    def _card(parent, padx_inner=20, pady_inner=16, **pack):
        """Return (outer_frame, content_frame). Pack outer with `outer.pack(...)`
        if you need control over pack order; otherwise pass pack kwargs here
        and we'll pack immediately. The returned content frame is where you
        add widgets."""
        outer = tk.Frame(parent, bg=C_CARD_BD, bd=0)
        if pack:
            outer.pack(**pack)
        inner = tk.Frame(outer, bg=C_CARD)
        inner.pack(fill="both", expand=True, padx=1, pady=1)
        pad = tk.Frame(inner, bg=C_CARD)
        pad.pack(fill="both", expand=True, padx=padx_inner, pady=pady_inner)
        # Expose the outer frame for late-packing scenarios.
        pad._card_outer = outer
        return pad

    # ---------------------------------------------------------------- header
    header = tk.Frame(root, bg=C_CANVAS)
    header.pack(fill="x", padx=22, pady=(18, 6))
    tk.Label(header, text="Well-Viz 3D",
             font=("Segoe UI", 20, "bold"),
             bg=C_CANVAS, fg=C_FG).pack(anchor="w")
    tk.Label(header,
             text="Upload your planned and actual surveys, then click Plot.",
             font=("Segoe UI", 10),
             bg=C_CANVAS, fg=C_FG_DIM).pack(anchor="w", pady=(3, 0))

    # ----------------------------------------------- upload card
    upload_card = _card(root, fill="x", padx=22, pady=(10, 8))
    tk.Label(upload_card, text="1.  Add survey files",
             font=("Segoe UI", 10, "bold"),
             bg=C_CARD, fg=C_FG).pack(anchor="w")
    tk.Label(upload_card,
             text="Tag each file as Planned or Actual. Files with matching "
                  "names auto-pair into a plan-vs-actual overlay.",
             font=("Segoe UI", 9), wraplength=720, justify="left",
             bg=C_CARD, fg=C_FG_DIM).pack(anchor="w", pady=(2, 12))

    btn_frame = tk.Frame(upload_card, bg=C_CARD)
    btn_frame.pack(fill="x")

    file_types = [
        ("Survey files", "*.csv *.json *.txt"),
        ("CSV",          "*.csv"),
        ("JSON",         "*.json"),
        ("All files",    "*.*"),
    ]

    def make_btn(parent, text, cmd, bg="#e2e8f0", fg=C_FG,
                 hover_bg=None, bold=False, pady=10, padx=16, size=10):
        font = ("Segoe UI", size, "bold" if bold else "normal")
        if hover_bg is None:
            hover_bg = bg
        btn = tk.Button(parent, text=text, command=cmd,
                        bg=bg, fg=fg, activebackground=hover_bg,
                        activeforeground=fg, relief="flat", borderwidth=0,
                        font=font, padx=padx, pady=pady, cursor="hand2")
        # Hover effect: brighten on enter, restore on leave.
        btn.bind("<Enter>", lambda _e, b=btn, c=hover_bg: b.configure(bg=c))
        btn.bind("<Leave>", lambda _e, b=btn, c=bg:        b.configure(bg=c))
        return btn

    def add_files(role):
        label = "planned" if role == "planned" else "actual"
        paths = filedialog.askopenfilenames(
            title=f"Choose {label} survey file(s)", filetypes=file_types)
        for p in paths:
            meta = _quick_metadata(p)
            state["files"].append({"path": p, "role": role, "name": None, "meta": meta})
        refresh_table()

    # Two large primary buttons, side by side.
    make_btn(btn_frame, "+  Add Planned Survey",
             lambda: add_files("planned"),
             bg="#1d4ed8", hover_bg="#1e40af", fg="white",
             bold=True, pady=12).pack(side="left", padx=(0, 10),
                                       fill="x", expand=True)
    make_btn(btn_frame, "+  Add Actual Survey",
             lambda: add_files("actual"),
             bg="#15803d", hover_bg="#166534", fg="white",
             bold=True, pady=12).pack(side="left", fill="x", expand=True)

    # --------------------------------------------------- loaded surveys card
    # Built but NOT packed yet — we'll pack it last so opt_card and
    # action_frame (pinned to the bottom) are always visible regardless
    # of how tall the list grows.
    list_card = _card(root, padx_inner=20, pady_inner=16)
    tk.Label(list_card, text="2.  Loaded surveys",
             font=("Segoe UI", 10, "bold"),
             bg=C_CARD, fg=C_FG).pack(anchor="w")
    tk.Label(list_card,
             text="Right-click a row to retag or rename. Double-click to rename.",
             font=("Segoe UI", 8),
             bg=C_CARD, fg=C_FG_MUTED).pack(anchor="w", pady=(2, 10))

    table_wrap = tk.Frame(list_card, bg=C_CARD_BD, bd=0)
    table_wrap.pack(fill="both", expand=True)

    cols = ("role", "file", "stations", "md_range", "class")
    tree = ttk.Treeview(table_wrap, columns=cols, show="headings",
                        selectmode="extended", height=8)
    tree.heading("role",     text="Role")
    tree.heading("file",     text="File / Name")
    tree.heading("stations", text="Stns")
    tree.heading("md_range", text="MD range")
    tree.heading("class",    text="Type")
    tree.column("role",     width=110, anchor="w")
    tree.column("file",     width=300, anchor="w")
    tree.column("stations", width=60,  anchor="e")
    tree.column("md_range", width=120, anchor="e")
    tree.column("class",    width=110, anchor="w")

    # Vertical scrollbar
    sb = ttk.Scrollbar(table_wrap, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=sb.set)
    sb.pack(side="right", fill="y")
    tree.pack(fill="both", expand=True)

    # Role-coloured rows
    tree.tag_configure("planned", foreground="#1e40af")
    tree.tag_configure("actual",  foreground="#166534")
    tree.tag_configure("error",   foreground="#b91c1c")

    def refresh_table():
        tree.delete(*tree.get_children())
        for i, f in enumerate(state["files"]):
            meta = f["meta"]
            role_label = "PLANNED" if f["role"] == "planned" else "ACTUAL"
            display_name = f["name"] or Path(f["path"]).name
            tag = "error" if meta.get("error") else f["role"]
            stns = "err" if meta.get("error") else str(meta.get("stations", "?"))
            cls = meta.get("error") or meta.get("classification", "—")
            tree.insert("", "end", iid=str(i),
                        values=(role_label, display_name, stns,
                                meta.get("md_range", "—"), cls),
                        tags=(tag,))

    # Right-click context menu to change role / rename
    menu = tk.Menu(tree, tearoff=0)

    def _change_role(role):
        for iid in tree.selection():
            state["files"][int(iid)]["role"] = role
        refresh_table()

    def _rename_one():
        sel = tree.selection()
        if not sel: return
        i = int(sel[0])
        from tkinter import simpledialog
        cur = state["files"][i]["name"] or Path(state["files"][i]["path"]).stem
        new = simpledialog.askstring("Rename", "Display name:", initialvalue=cur, parent=root)
        if new is not None:
            state["files"][i]["name"] = new.strip() or None
            refresh_table()

    def _remove_selected():
        for iid in sorted((int(i) for i in tree.selection()), reverse=True):
            state["files"].pop(iid)
        refresh_table()

    menu.add_command(label="Tag as Planned", command=lambda: _change_role("planned"))
    menu.add_command(label="Tag as Actual",  command=lambda: _change_role("actual"))
    menu.add_separator()
    menu.add_command(label="Rename…",          command=_rename_one)
    menu.add_command(label="Remove from list", command=_remove_selected)

    def on_right_click(event):
        rid = tree.identify_row(event.y)
        if rid:
            if rid not in tree.selection():
                tree.selection_set(rid)
            menu.post(event.x_root, event.y_root)
    tree.bind("<Button-3>", on_right_click)
    tree.bind("<Delete>", lambda e: _remove_selected())
    tree.bind("<Double-1>", lambda e: _rename_one())

    # ----------------------------------------------- list manipulation buttons
    list_btn_row = tk.Frame(list_card, bg=C_CARD)
    list_btn_row.pack(fill="x", pady=(10, 0))
    make_btn(list_btn_row, "Remove",
             _remove_selected, bg="#fee2e2", fg="#991b1b",
             hover_bg="#fecaca", pady=6, padx=12, size=9
             ).pack(side="left")
    make_btn(list_btn_row, "Rename",
             _rename_one, bg="#e0f2fe", fg="#075985",
             hover_bg="#bae6fd", pady=6, padx=12, size=9
             ).pack(side="left", padx=(6, 0))
    make_btn(list_btn_row, "Clear all",
             lambda: (state["files"].clear(), refresh_table()),
             bg="#f1f5f9", fg=C_FG_DIM, hover_bg="#e2e8f0",
             pady=6, padx=12, size=9
             ).pack(side="left", padx=(6, 0))

    # ----------------------------------------------- display options card
    # Pinned to the BOTTOM-second slot so the action buttons sit beneath it.
    opt_card = _card(root, padx_inner=20, pady_inner=14)
    tk.Label(opt_card, text="3.  Display options",
             font=("Segoe UI", 10, "bold"),
             bg=C_CARD, fg=C_FG).pack(anchor="w")
    tk.Label(opt_card,
             text="Start with these panels turned on. You can also toggle "
                  "them later from the ≡ Menu inside the plot window.",
             font=("Segoe UI", 8),
             bg=C_CARD, fg=C_FG_MUTED).pack(anchor="w", pady=(2, 10))

    opt_grid = tk.Frame(opt_card, bg=C_CARD)
    opt_grid.pack(fill="x")

    md_var       = tk.BooleanVar(value=True)
    plan_var     = tk.BooleanVar(value=True)
    section_var  = tk.BooleanVar(value=True)
    dev_var      = tk.BooleanVar(value=True)
    dls_var      = tk.BooleanVar(value=False)

    chk_opts = dict(bg=C_CARD, fg=C_FG, activebackground=C_CARD,
                    selectcolor=C_CARD, font=("Segoe UI", 9),
                    cursor="hand2")
    tk.Checkbutton(opt_grid, text="MD markers", variable=md_var,
                   **chk_opts).grid(row=0, column=0, sticky="w", padx=(0, 24), pady=2)
    tk.Checkbutton(opt_grid, text="Plan view (top-down)", variable=plan_var,
                   **chk_opts).grid(row=0, column=1, sticky="w", padx=(0, 24), pady=2)
    tk.Checkbutton(opt_grid, text="Section view (horiz × TVD)", variable=section_var,
                   **chk_opts).grid(row=0, column=2, sticky="w", pady=2)
    tk.Checkbutton(opt_grid, text="Plan-vs-actual deviation panel",
                   variable=dev_var, **chk_opts
                   ).grid(row=1, column=0, columnspan=2, sticky="w", padx=(0, 24), pady=2)
    tk.Checkbutton(opt_grid, text="DLS heatmap colouring",
                   variable=dls_var, **chk_opts
                   ).grid(row=1, column=2, sticky="w", pady=2)

    # ---------------------------------------------------------- action buttons
    # Built without packing — we attach to root with side="bottom" below.
    action_frame = tk.Frame(root, bg=C_CANVAS)

    plot_holder = {"clicked": False}

    def do_plot():
        if not state["files"]:
            messagebox.showwarning("No files",
                                   "Add at least one survey file first.",
                                   parent=root)
            return
        # Warn if any rows had load errors.
        errs = [Path(f["path"]).name for f in state["files"] if f["meta"].get("error")]
        if errs:
            if not messagebox.askyesno(
                    "File errors",
                    f"These file(s) failed to parse and will be skipped:\n  "
                    + "\n  ".join(errs)
                    + "\n\nContinue anyway?",
                    parent=root):
                return
        # Build bores from non-error rows.
        usable = [f for f in state["files"] if not f["meta"].get("error")]
        try:
            bores = _build_bores_for_gui(usable)
        except Exception as exc:
            messagebox.showerror("Load error", str(exc), parent=root)
            return

        plot_holder.update({
            "clicked":  True,
            "bores":    bores,
            "md":       md_var.get(),
            "plan":     plan_var.get(),
            "section":  section_var.get(),
            "dev":      dev_var.get(),
            "dls":      dls_var.get(),
        })
        root.destroy()

    make_btn(action_frame, "Cancel", root.destroy,
             bg="#f1f5f9", fg=C_FG_DIM, hover_bg="#e2e8f0",
             pady=10, padx=18).pack(side="right", padx=(8, 0))
    make_btn(action_frame, "Plot  ▶", do_plot,
             bg=C_ACCENT, fg="white", hover_bg="#0369a1",
             bold=True, pady=10, padx=22).pack(side="right")

    # ---- Final pack order: pin action_frame + opt_card to bottom, then
    # let the loaded-surveys list_card fill the middle. tkinter's pack
    # gives each item its natural size first, and items packed with
    # side="bottom" reserve space at the bottom of the canvas regardless
    # of how tall the expanding list_card grows. So the Plot button is
    # always visible no matter how many files are loaded.
    action_frame._card_outer = action_frame  # tag for symmetry
    action_frame.pack(side="bottom", fill="x", padx=22, pady=(8, 18))
    opt_card._card_outer.pack(side="bottom", fill="x", padx=22, pady=(0, 8))
    list_card._card_outer.pack(side="top", fill="both", expand=True,
                                padx=22, pady=8)

    refresh_table()
    root.mainloop()

    if plot_holder.get("clicked"):
        return {
            "bores":   plot_holder["bores"],
            "md":      plot_holder["md"],
            "plan":    plot_holder["plan"],
            "section": plot_holder["section"],
            "dev":     plot_holder["dev"],
            "dls":     plot_holder["dls"],
        }
    return None


def _build_bores_for_gui(file_entries: List[dict]) -> List[dict]:
    """Translate the GUI's file list into the bores structure plot_wells wants.

    The simplified GUI surfaces only two roles: planned and actual. Files are
    paired positionally via load_plan_vs_actual so a single planned+actual
    yields a paired overlay, and lone actuals (e.g. just one actual loaded)
    render as a solid bore on their own.
    """
    planned = [f["path"] for f in file_entries if f["role"] == "planned"]
    actual  = [f["path"] for f in file_entries if f["role"] == "actual"]

    planned_names = [f["name"] for f in file_entries if f["role"] == "planned"]
    actual_names  = [f["name"] for f in file_entries if f["role"] == "actual"]

    # Pair-share label: prefer the actual-side name when present.
    pa_names = [a or p for p, a in
                zip(planned_names + [None] * len(actual_names),
                    actual_names + [None] * len(planned_names))]
    pa_names = [n for n in pa_names if n] or None

    if not planned and not actual:
        return []

    return load_plan_vs_actual(
        planned_paths=planned,
        actual_paths=actual,
        names=pa_names,
    )


# ===========================================================================
# 4. CLI
# ===========================================================================

def _base_dir() -> Path:
    """Resolve the application's base directory.

    When frozen by PyInstaller (--onefile), bundled data files are extracted
    to sys._MEIPASS at runtime. Otherwise we fall back to the script's folder.
    """
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parent


BASE_DIR = _base_dir()
DATA_DIR = BASE_DIR / "data"


def list_examples() -> List[Path]:
    if not DATA_DIR.exists():
        return []
    return sorted(p for p in DATA_DIR.iterdir() if p.suffix.lower() in {".csv", ".json"})


def find_example(name: str) -> Optional[Path]:
    """Look up an example by stem name (case-insensitive)."""
    target = name.lower()
    for p in list_examples():
        if p.stem.lower() == target:
            return p
    return None


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Visualize a directional drilling survey in 3D.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""\
Examples:
  py well_viz.py                            (loads bundled "deviated" example)
  py well_viz.py survey.csv                 (single well)
  py well_viz.py L1.csv L2.csv L3.csv       (3-leg multilateral, one file per leg)
  py well_viz.py L1.csv L2.csv --names "Main,North Lateral"
  py well_viz.py --example sagd-pair        (bundled multi-bore JSON)
  py well_viz.py --planned plan.csv --actual actual.csv
                                            (plan-vs-actual overlay,
                                             plan dashed/translucent)
  py well_viz.py --planned p1.csv p2.csv --actual a1.csv a2.csv
                                            (multi-leg plan vs actual)
  py well_viz.py --list-examples
""",
    )
    parser.add_argument(
        "source", nargs="*",
        help='Path(s) to CSV or JSON survey files. If you pass more than one '
             'file, each is rendered as a separate leg of a multilateral well '
             '(each file should contain a full survey from surface to that '
             'leg\'s toe). Use "-" as a single argument to read one survey from stdin.',
    )
    parser.add_argument(
        "--example", "-e", metavar="NAME",
        help='Name of a bundled example (e.g. "vertical", "horizontal", '
             '"sagd-pair", "multilateral-legs").',
    )
    parser.add_argument(
        "--names", metavar="N1,N2,...",
        help="Comma-separated leg names, applied positionally. "
             'Example: --names "Main,Lateral North,Lateral South"',
    )
    parser.add_argument(
        "--colors", metavar="C1,C2,...",
        help='Comma-separated hex colours, applied positionally. '
             'Example: --colors "#38bdf8,#22c55e,#f97316"',
    )
    parser.add_argument(
        "--planned", nargs="+", metavar="PATH",
        help="One or more planned-survey files. Rendered dashed and "
             "translucent. Pair with --actual file(s) of the same length "
             "to compare plan vs as-drilled.",
    )
    parser.add_argument(
        "--actual", nargs="+", metavar="PATH",
        help="One or more actual / as-drilled survey files. Rendered solid. "
             "Each --actual file is paired positionally with the matching "
             "--planned file; the pair shares a colour.",
    )
    parser.add_argument(
        "--gui", action="store_true",
        help="Open the upload window (file pickers for planned / actual / "
             "standalone surveys), then plot when you click 'Plot in 3D'. "
             "Useful when you don't want to type paths on the command line.",
    )
    parser.add_argument(
        "--list-examples", action="store_true",
        help="List the bundled example datasets and exit.",
    )
    parser.add_argument(
        "--no-markers", action="store_true",
        help="Hide MD markers along the wellpath.",
    )
    parser.add_argument(
        "--color-by-dls", action="store_true",
        help="Colour the trajectory line by dogleg severity instead of by bore. "
             "Adds a colourbar; high-DLS zones (potential casing/string-risk "
             "areas) are highlighted in warm colours.",
    )
    parser.add_argument(
        "--no-plan-view", action="store_true",
        help="Hide the top-down plan-view inset panel.",
    )
    parser.add_argument(
        "--no-section-view", action="store_true",
        help="Hide the vertical-section inset panel.",
    )
    parser.add_argument(
        "--no-deviation-panel", action="store_true",
        help="Hide the plan-vs-actual deviation panel (only shown when plan + "
             "actual pairs are present anyway).",
    )
    parser.add_argument(
        "--densify", type=float, default=50.0, metavar="STEP",
        help="MD step (in survey units) for visual smoothing between stations. "
             "Default 50. Use 0 to draw raw chord segments.",
    )
    parser.add_argument(
        "--save", metavar="PNG",
        help="Save the plot to a PNG file instead of opening a window.",
    )
    parser.add_argument(
        "--stdin-format", choices=("csv", "json"), default="csv",
        help='Format when reading from stdin. Auto-detected if input begins with { or [.',
    )
    args = parser.parse_args(argv)

    # --- GUI takes precedence over CLI input modes -------------------------
    if args.gui:
        return launch_gui() or 0

    # --- list examples ------------------------------------------------------
    if args.list_examples:
        examples = list_examples()
        if not examples:
            print("No examples bundled. Drop CSV/JSON files into the data/ folder.")
            return 0
        print("Bundled examples (use --example <name>):")
        for p in examples:
            print(f"  {p.stem:18s}  {p.name}")
        return 0

    # Parse --names and --colors lists once so all branches can use them.
    name_list = [s.strip() for s in args.names.split(",")] if args.names else None
    color_list = [s.strip() for s in args.colors.split(",")] if args.colors else None

    # --- choose input source ------------------------------------------------
    bores: List[dict]
    sources = args.source or []
    # Plan-vs-actual mode takes precedence: if the user passed either flag
    # we route through load_plan_vs_actual regardless of positional sources.
    if args.planned or args.actual:
        if sources:
            print("(--planned/--actual given; ignoring positional file arguments)",
                  file=sys.stderr)
        bores = load_plan_vs_actual(
            planned_paths=args.planned or [],
            actual_paths=args.actual or [],
            names=name_list,
            colors=color_list,
        )
        n_plans = sum(1 for b in bores if (b.get("role") or "").lower() == "planned")
        n_acts = sum(1 for b in bores if (b.get("role") or "").lower() == "actual")
        print(f"(Plan vs actual: {n_plans} planned bore(s), {n_acts} actual bore(s))")
    elif sources == ["-"]:
        text = sys.stdin.read()
        bores = load_from_text(text, format=args.stdin_format)
    elif len(sources) > 1:
        # Multi-leg: each file is one leg of a multilateral.
        print(f"(Loading {len(sources)} legs as a multilateral well)")
        bores = load_legs(sources, names=name_list, colors=color_list)
    elif args.example:
        path = find_example(args.example)
        if path is None:
            avail = ", ".join(p.stem for p in list_examples()) or "(none bundled)"
            print(f"Example '{args.example}' not found. Available: {avail}", file=sys.stderr)
            return 2
        bores = load_survey(str(path))
    elif sources:
        bores = load_survey(sources[0])
    else:
        # No source given — open the upload GUI first so double-clicking the
        # script just works. Falls back to the bundled example only if tkinter
        # isn't available (rare; some headless Linux Python builds).
        try:
            import tkinter  # noqa: F401
            return launch_gui() or 0
        except ImportError:
            path = find_example("deviated") or (list_examples()[0] if list_examples() else None)
            if path is None:
                parser.print_help()
                print("\nNo survey file given and no examples available.", file=sys.stderr)
                return 2
            print(f"(No file given, no GUI available — loading example '{path.stem}')")
            bores = load_survey(str(path))

    # Apply --names / --colors to single-file loads too, so users can override
    # labels on a multi-bore JSON without having to edit the file.
    if (name_list or color_list) and len(sources) <= 1:
        if name_list:
            for i, override in enumerate(name_list):
                if i < len(bores) and override:
                    bores[i]["name"] = override
        if color_list:
            for i, override in enumerate(color_list):
                if i < len(bores) and override:
                    bores[i]["color"] = override

    plot_wells(
        bores,
        densify_step=args.densify,
        show_md_markers=not args.no_markers,
        save_path=args.save,
        color_by_dls=args.color_by_dls,
        show_plan_view=not args.no_plan_view,
        show_section_view=not args.no_section_view,
        show_deviation_panel=not args.no_deviation_panel,
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
