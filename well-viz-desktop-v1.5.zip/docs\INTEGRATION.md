# Well-Viz Desktop — Integration Guide

Patterns for embedding the trajectory engine and 3-D viewer into other
applications, and for porting the math to languages or rendering stacks
beyond the bundled matplotlib viewer.

For the math background see [`TECHNICAL_PAPER.md`](TECHNICAL_PAPER.md).
For a code walkthrough see [`CODE_GUIDE.md`](CODE_GUIDE.md).

---

## 1. As a Python library

`well_viz.py` is import-friendly. The math, parsing, and rendering are
discoverable top-level functions with stable signatures.

### Minimal trajectory calculation

```python
from well_viz import minimum_curvature, compute_summary

stations = [
    {"md": 0,    "inc": 0,  "azi": 0},
    {"md": 1500, "inc": 0,  "azi": 0},
    {"md": 2500, "inc": 45, "azi": 90},
    {"md": 6000, "inc": 45, "azi": 90},
]

trajectory = minimum_curvature(stations)
summary    = compute_summary(trajectory)

print(f"{summary['classification']}: "
      f"TVD {summary['totalTvd']:.0f}, reach {summary['horizontalReach']:.0f}")
# → deviated: TVD 4875, reach 2848
```

`trajectory` is a list of dicts with `md, inc, azi, north, east, tvd, dls,
horizontalDisplacement` — feed it straight into pandas, numpy, your own
plotter, an HTTP response, or a database.

### Round-trip CSV → trajectory → DataFrame

```python
import pandas as pd
from well_viz import parse_csv, minimum_curvature

with open("survey.csv") as f:
    stations = parse_csv(f.read())

df = pd.DataFrame(minimum_curvature(stations))
df.to_parquet("trajectory.parquet")
```

### Multi-bore (multilateral / SAGD)

```python
from well_viz import load_survey, load_legs

# A single file holding multiple bores under "bores":
bores = load_survey("multilateral.json")

# Or one CSV per leg:
bores = load_legs(
    ["leg-main.csv", "leg-north.csv", "leg-south.csv"],
    names=["Main", "North", "South"],
)

for bore in bores:
    # `stations` here is still raw {md, inc, azi}; run minimum_curvature
    # yourself if you want the 3D coordinates without going through the plotter.
    from well_viz import minimum_curvature
    traj = minimum_curvature(bore["stations"])
    print(bore["name"], "→", len(traj), "stations")
```

### Headless plot rendering (no GUI)

For automated reports, CI pipelines, or server-side image generation:

```python
import matplotlib
matplotlib.use("Agg")  # MUST come before any pyplot import

from well_viz import load_survey, plot_wells

bores = load_survey("data/horizontal.csv")
plot_wells(bores, save_path="horizontal.png")
```

The `Agg` backend is non-interactive — no window will appear and no display
server is required, so the same call works on a headless Linux server,
inside Docker, or under WSL without an X server.

---

## 2. Web / REST integration

The math engine is pure-Python with no global state, so it slots into any
WSGI / ASGI / serverless function.

### Flask example

```python
from flask import Flask, jsonify, request
from well_viz import parse_csv, parse_json, minimum_curvature, compute_summary

app = Flask(__name__)

@app.post("/api/trajectory")
def trajectory():
    body = request.get_json()
    fmt = body.get("format", "csv")
    if fmt == "json":
        bores = parse_json(body["data"])["bores"]
    else:
        bores = [{"name": "Wellbore", "stations": parse_csv(body["data"])}]

    out = []
    for b in bores:
        traj = minimum_curvature(b["stations"])
        out.append({
            "name": b["name"],
            "stations": traj,
            "summary": compute_summary(traj),
        })
    return jsonify(bores=out)
```

### FastAPI / Starlette

The same shape works under FastAPI — the only library functions you need
are `parse_csv`, `parse_json`, `minimum_curvature`, and `compute_summary`.
None of them touch matplotlib or the filesystem.

### Pre-rendered images

If your service needs to return PNGs rather than coordinate arrays, render
to an `io.BytesIO` and stream:

```python
import io, matplotlib
matplotlib.use("Agg")
from flask import send_file
from well_viz import load_from_text, plot_wells

@app.post("/api/plot.png")
def plot_png():
    bores = load_from_text(request.get_data(as_text=True))
    buf = io.BytesIO()
    plot_wells(bores, save_path=buf)   # save_path accepts file-like objects
    buf.seek(0)
    return send_file(buf, mimetype="image/png")
```

---

## 3. Jupyter notebooks

In Jupyter, matplotlib's `%matplotlib widget` (with `ipympl` installed) or
`%matplotlib notebook` gives you a fully interactive 3-D plot inline. The
`plot_wells` function works unmodified:

```python
%matplotlib widget
from well_viz import load_survey, plot_wells
plot_wells(load_survey("data/horizontal.csv"))
```

For static notebook output (HTML export), use the default `inline` backend
— the plot will render as a still image. That's the same path as
`save_path` PNG generation.

---

## 4. Porting to other 3-D engines

The math and parsing are decoupled from the viewer. To swap matplotlib for
another renderer, keep sections 1 and 2 of `well_viz.py` and replace
`plot_wells` with the equivalent for your stack.

### PyVista (VTK)

PyVista handles tens of thousands of points smoothly via GPU pipelines.
Sketch:

```python
import numpy as np, pyvista as pv
from well_viz import load_survey, minimum_curvature, densify

plotter = pv.Plotter()
for bore in load_survey("data/multilateral.json"):
    traj = densify(minimum_curvature(bore["stations"]))
    pts = np.array([[s["east"], s["north"], -s["tvd"]] for s in traj])
    spline = pv.Spline(pts, 1000)
    tube = spline.tube(radius=8)
    plotter.add_mesh(tube, color=bore.get("color", "#0284c7"))
plotter.show()
```

### Three.js (browser)

Use the trajectory list returned by `minimum_curvature` straight from a
JSON API. The earlier Flask + Three.js variant of this project (in the
sibling `well-viz-py/` directory of the workspace) demonstrates the full
pattern: serialise stations to JSON, then build a `THREE.CatmullRomCurve3`
through them and sweep a `THREE.TubeGeometry` along it.

### Plotly

Plotly's `scatter3d` produces a self-contained HTML file that opens in any
browser. Convenient for sharing well plans by email:

```python
import plotly.graph_objects as go
from well_viz import load_survey, minimum_curvature

fig = go.Figure()
for bore in load_survey("data/horizontal.csv"):
    traj = minimum_curvature(bore["stations"])
    fig.add_trace(go.Scatter3d(
        x=[s["east"]  for s in traj],
        y=[s["north"] for s in traj],
        z=[-s["tvd"]  for s in traj],
        mode="lines", line=dict(width=6), name=bore["name"],
    ))
fig.update_layout(scene=dict(zaxis=dict(autorange="reversed")))
fig.write_html("well.html")
```

### Bokeh / Panel dashboard

For larger applications where the well viewer is one panel among many,
Panel + PyVista or Panel + Plotly both work. The same data-flow applies:
parse → minimum_curvature → hand the trajectory array to the panel.

---

## 5. Porting the math to other languages

The minimum-curvature method is twelve lines of arithmetic per station
pair. The implementation in `well_viz.py:minimum_curvature` is a faithful
reference; here are the same equations in three other languages.

### JavaScript / TypeScript

```javascript
function trajectory(stations) {
  const deg = d => d * Math.PI / 180;
  const out = [{...stations[0], north: 0, east: 0, tvd: 0, dls: 0}];
  for (let i = 1; i < stations.length; i++) {
    const p = out[i - 1], c = stations[i];
    const dMD = c.md - p.md;
    const i1 = deg(p.inc), i2 = deg(c.inc);
    const a1 = deg(p.azi), a2 = deg(c.azi);
    const cosDL = Math.cos(i2 - i1) - Math.sin(i1) * Math.sin(i2) * (1 - Math.cos(a2 - a1));
    const dl = Math.acos(Math.max(-1, Math.min(1, cosDL)));
    const rf = dl < 1e-9 ? 1 : (2 / dl) * Math.tan(dl / 2);
    const dN = (dMD / 2) * (Math.sin(i1) * Math.cos(a1) + Math.sin(i2) * Math.cos(a2)) * rf;
    const dE = (dMD / 2) * (Math.sin(i1) * Math.sin(a1) + Math.sin(i2) * Math.sin(a2)) * rf;
    const dT = (dMD / 2) * (Math.cos(i1) + Math.cos(i2)) * rf;
    out.push({
      ...c,
      north: p.north + dN, east: p.east + dE, tvd: p.tvd + dT,
      dls: (dl * 180 / Math.PI) * 100 / dMD,
    });
  }
  return out;
}
```

### C# / .NET

```csharp
public static List<Station> Trajectory(IReadOnlyList<Station> stations)
{
    double Deg(double d) => d * Math.PI / 180.0;
    var first = stations[0] with { North = 0, East = 0, Tvd = 0, Dls = 0 };
    var result = new List<Station> { first };
    for (int i = 1; i < stations.Count; i++)
    {
        var p = result[i - 1];
        var c = stations[i];
        double dMD = c.Md - p.Md;
        double i1 = Deg(p.Inc), i2 = Deg(c.Inc);
        double a1 = Deg(p.Azi), a2 = Deg(c.Azi);
        double cosDl = Math.Cos(i2 - i1) - Math.Sin(i1) * Math.Sin(i2) * (1 - Math.Cos(a2 - a1));
        double dl = Math.Acos(Math.Clamp(cosDl, -1.0, 1.0));
        double rf = dl < 1e-9 ? 1.0 : (2.0 / dl) * Math.Tan(dl / 2.0);
        double dN = (dMD / 2) * (Math.Sin(i1) * Math.Cos(a1) + Math.Sin(i2) * Math.Cos(a2)) * rf;
        double dE = (dMD / 2) * (Math.Sin(i1) * Math.Sin(a1) + Math.Sin(i2) * Math.Sin(a2)) * rf;
        double dT = (dMD / 2) * (Math.Cos(i1) + Math.Cos(i2)) * rf;
        result.Add(c with {
            North = p.North + dN, East = p.East + dE, Tvd = p.Tvd + dT,
            Dls   = dl * (180.0 / Math.PI) * 100.0 / dMD
        });
    }
    return result;
}
```

### MATLAB

```matlab
function out = trajectory(stations)
  d2r = @(x) x * pi / 180;
  n   = size(stations, 1);
  out = zeros(n, 7);  % md inc azi N E TVD DLS
  out(1, 1:3) = stations(1, :);
  for i = 2:n
      p = out(i-1, :);  c = stations(i, :);
      dMD = c(1) - p(1);
      i1 = d2r(p(2)); i2 = d2r(c(2));
      a1 = d2r(p(3)); a2 = d2r(c(3));
      cosDL = cos(i2 - i1) - sin(i1) * sin(i2) * (1 - cos(a2 - a1));
      dl = acos(min(1, max(-1, cosDL)));
      if dl < 1e-9, rf = 1; else, rf = (2 / dl) * tan(dl / 2); end
      dN = (dMD/2) * (sin(i1)*cos(a1) + sin(i2)*cos(a2)) * rf;
      dE = (dMD/2) * (sin(i1)*sin(a1) + sin(i2)*sin(a2)) * rf;
      dT = (dMD/2) * (cos(i1) + cos(i2)) * rf;
      out(i, :) = [c(1), c(2), c(3), p(4)+dN, p(5)+dE, p(6)+dT, rad2deg(dl)*100/dMD];
  end
end
```

All three pass the same closed-form tests as the Python reference. When
adapting, the only items easy to get wrong are:

1. **The sign of cos(A₂ − A₁)** — sign errors here produce mirrored
   trajectories that look plausible at a glance.
2. **Degrees vs radians** — `acos` returns radians; DLS must be in degrees.
3. **The `RF → 1` limit** — division by `dl` near zero produces NaNs in
   straight-hole sections.
4. **TVD sign convention** — positive-down is industry standard; some
   visualisation libraries default to positive-up and silently flip the well.

---

## 6. Coordinate frame interop

The output frame is *(North, East, TVD-positive-down)*. Common conversions:

| Target frame                | Transformation                                  |
|-----------------------------|-------------------------------------------------|
| Right-handed `(X, Y, Z)`    | $X = E,\;Y = N,\;Z = -\text{TVD}$               |
| OpenGL / glTF `(X, Y, Z)`   | $X = E,\;Y = -\text{TVD},\;Z = -N$              |
| Local / map projection      | Add easting / northing of the wellhead reference|
| Survey datum (NAD83, WGS84) | Apply a survey grid transform then add wellhead |

For georeferenced output (linking the trajectory to a basin / lease map),
treat the wellhead's surface (X, Y) coordinates as the origin of the local
frame, then add the trajectory's (E, N) deltas to the wellhead's
easting / northing in your survey-grid CRS.

---

## 7. Compliance & accuracy

The bundled implementation matches the minimum-curvature reference equations
in API RP 78 and the SPE literature (see §9 of `TECHNICAL_PAPER.md`). For
regulatory or anti-collision work you will typically need additional
machinery beyond the trajectory itself:

- **Survey-tool error models** (ISCWSA error budgets) for position
  uncertainty ellipsoids.
- **Geomagnetic / grid corrections** (declination, convergence) to convert
  magnetic azimuth into grid azimuth.
- **Anti-collision separation factor (SF)** calculations against neighbouring
  wells.

These are deliberately outside the scope of Well-Viz Desktop, which focuses
on the trajectory math and visualization itself. The data model is friendly
to layering them on: the per-station dict can hold any extra fields, and
the rendering loop ignores fields it doesn't recognise.

---

## 8. License

Original code and documentation are provided as a reference implementation;
adapt freely. Please preserve the citation of source references in
`TECHNICAL_PAPER.md` §9 in derivative works.
